<script lang="ts">
import Icon from '@/components/core/Icon.svelte'

import { chatbotIconPath } from './iconPaths'
</script>

<Icon path={chatbotIconPath} />
