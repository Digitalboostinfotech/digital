export const STORAGE_PREFIX = 'ssupp'
export const DEFAULT_STORAGE_EXPIRATION_IN_DAYS = 182
