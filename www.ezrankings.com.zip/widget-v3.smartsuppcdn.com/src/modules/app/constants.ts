/** Some (not)browsers trigger at first the `visibilitychange` event and later change the state of its `document.visibilityState`.. */
export const DOCUMENT_VISIBILITY_DELAY = 500
export const CONNECTION_STATUS_DELAY = 1500
export const DEV_ENVS = ['smartsupp.dev', 'smartsuppchat.loc']
