export const DEFAULT_GROUP = 'default'
