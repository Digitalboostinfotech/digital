export const Key = {
	Enter: 'Enter',
} as const

export const TEXTAREA_MAX_LENGTH = 2000
export const MESSAGE_SENT_CONFIRMATION_DURATION = 2000
