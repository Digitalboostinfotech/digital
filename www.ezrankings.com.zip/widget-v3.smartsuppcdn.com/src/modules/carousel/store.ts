import { writable } from 'svelte/store'

export const isDraging = writable<boolean>(false)
