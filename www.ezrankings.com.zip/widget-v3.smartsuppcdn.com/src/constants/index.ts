export * from './testIds'

export const SMARTSUPP_URL = 'https://www.smartsupp.com'
export const POWERED_BY_SS_PATH = '/powered-by-smartsupp'
export const WEB_SUPPORTED_LANGUAGES = ['cs', 'es', 'fr', 'hu', 'it', 'de', 'nl', 'pl']
export const WIDGET_VERSION = '3.0'
export const GDPR_PLACEHOLDER_URL = 'https://www.smartsupp.com/my-data-and-gdpr'
