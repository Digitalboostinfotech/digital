/* clarity-js v0.8.9: https://github.com/microsoft/clarity (License: MIT) */ ! function() {
    "use strict";
    var t = Object.freeze({
            __proto__: null,
            get add() {
                return Ma
            },
            get get() {
                return Ya
            },
            get getId() {
                return Ea
            },
            get getNode() {
                return Aa
            },
            get getValue() {
                return Xa
            },
            get has() {
                return La
            },
            get hashText() {
                return Ra
            },
            get iframe() {
                return _a
            },
            get iframeContent() {
                return Ia
            },
            get lookup() {
                return ja
            },
            get parse() {
                return Ta
            },
            get removeIFrame() {
                return Ca
            },
            get sameorigin() {
                return xa
            },
            get start() {
                return ka
            },
            get stop() {
                return Sa
            },
            get update() {
                return Na
            },
            get updates() {
                return Wa
            }
        }),
        e = Object.freeze({
            __proto__: null,
            get queue() {
                return kr
            },
            get start() {
                return wr
            },
            get stop() {
                return Sr
            },
            get track() {
                return hr
            }
        }),
        n = Object.freeze({
            __proto__: null,
            get data() {
                return $r
            },
            get start() {
                return ti
            },
            get stop() {
                return ni
            },
            get upgrade() {
                return ei
            }
        }),
        a = Object.freeze({
            __proto__: null,
            get check() {
                return ii
            },
            get compute() {
                return ui
            },
            get data() {
                return Qr
            },
            get start() {
                return ri
            },
            get stop() {
                return ci
            },
            get trigger() {
                return oi
            }
        }),
        r = Object.freeze({
            __proto__: null,
            get compute() {
                return vi
            },
            get data() {
                return si
            },
            get log() {
                return hi
            },
            get reset() {
                return gi
            },
            get start() {
                return fi
            },
            get stop() {
                return pi
            },
            get updates() {
                return li
            }
        }),
        i = Object.freeze({
            __proto__: null,
            get callback() {
                return xi
            },
            get callbacks() {
                return bi
            },
            get clear() {
                return Ni
            },
            get consent() {
                return Mi
            },
            get data() {
                return yi
            },
            get electron() {
                return wi
            },
            get id() {
                return Ei
            },
            get metadata() {
                return Ti
            },
            get save() {
                return _i
            },
            get shortid() {
                return Di
            },
            get start() {
                return Si
            },
            get stop() {
                return Oi
            }
        }),
        o = Object.freeze({
            __proto__: null,
            get data() {
                return Li
            },
            get envelope() {
                return Hi
            },
            get start() {
                return Wi
            },
            get stop() {
                return zi
            }
        }),
        u = {
            projectId: null,
            delay: 1e3,
            lean: !1,
            lite: !1,
            track: !0,
            content: !0,
            drop: [],
            mask: [],
            unmask: [],
            regions: [],
            cookies: [],
            fraud: !0,
            checksum: [],
            report: null,
            upload: null,
            fallback: null,
            upgrade: null,
            action: null,
            dob: null,
            delayDom: !1,
            throttleDom: !0,
            conversions: !1,
            includeSubdomains: !0
        };

    function c(t) {
        return window.Zone && "__symbol__" in window.Zone ? window.Zone.__symbol__(t) : t
    }
    var s = 0;

    function l(t) {
        void 0 === t && (t = null);
        var e = t && t.timeStamp > 0 ? t.timeStamp : performance.now(),
            n = t && t.view ? t.view.performance.timeOrigin : performance.timeOrigin;
        return Math.max(Math.round(e + n - s), 0)
    }
    var d = "0.8.9";

    function f(t, e) {
        void 0 === e && (e = null);
        for (var n, a = 5381, r = a, i = 0; i < t.length; i += 2) {
            if (a = (a << 5) + a ^ t.charCodeAt(i), i + 1 < t.length) r = (r << 5) + r ^ t.charCodeAt(i + 1)
        }
        return n = Math.abs(a + 11579 * r), (e ? n % Math.pow(2, e) : n).toString(36)
    }
    var p = /\S/gi,
        h = 255,
        v = !0,
        g = null,
        m = null,
        y = null;

    function b(t, e, n, a, r) {
        if (void 0 === a && (a = !1), t) {
            if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
            switch (n) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return function(t) {
                                var e = -1,
                                    n = 0,
                                    a = !1,
                                    r = !1,
                                    i = !1,
                                    o = null;
                                E();
                                for (var u = 0; u < t.length; u++) {
                                    var c = t.charCodeAt(u);
                                    if (a = a || c >= 48 && c <= 57, r = r || 64 === c, i = 9 === c || 10 === c || 13 === c || 32 === c, 0 === u || u === t.length - 1 || i) {
                                        if (a || r) {
                                            null === o && (o = t.split(""));
                                            var s = t.substring(e + 1, i ? u : u + 1);
                                            s = v && null !== y ? s.match(y) ? s : O(s, "▪", "▫") : S(s), o.splice(e + 1 - n, s.length, s), n += s.length - 1
                                        }
                                        i && (a = !1, r = !1, e = u)
                                    }
                                }
                                return o ? o.join("") : t
                            }(t);
                        case "input":
                        case "change":
                            return T(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? k(t) : S(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                            return 3 === n ? "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return T(t);
                        case "placeholder":
                            return S(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? k(t) : S(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return O(t, "▪", "▫");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
            }
        }
        return t
    }

    function w(t, e, n) {
        void 0 === e && (e = !1), void 0 === n && (n = !1);
        var a = t;
        if (e) a = "".concat("https://").concat("Electron");
        else {
            var r = u.drop;
            if (r && r.length > 0 && t && t.indexOf("?") > 0) {
                var i = t.split("?"),
                    o = i[0],
                    c = i[1];
                a = o + "?" + c.split("&").map((function(t) {
                    return r.some((function(e) {
                        return 0 === t.indexOf("".concat(e, "="))
                    })) ? "".concat(t.split("=")[0], "=").concat("*na*") : t
                })).join("&")
            }
        }
        return n && (a = a.substring(0, h)), a
    }

    function k(t) {
        var e = t.trim();
        if (e.length > 0) {
            var n = e[0],
                a = t.indexOf(n),
                r = t.substr(0, a),
                i = t.substr(a + e.length);
            return "".concat(r).concat(e.length.toString(36)).concat(i)
        }
        return t
    }

    function S(t) {
        return t.replace(p, "•")
    }

    function O(t, e, n) {
        return E(), t ? t.replace(m, e).replace(g, n) : t
    }

    function T(t) {
        for (var e = 5 * (Math.floor(t.length / 5) + 1), n = "", a = 0; a < e; a++) n += a > 0 && a % 5 == 0 ? " " : "•";
        return n
    }

    function E() {
        if (v && null === g) try {
            g = new RegExp("\\p{N}", "gu"), m = new RegExp("\\p{L}", "gu"), y = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            v = !1
        }
    }
    var M = null,
        N = null,
        x = !1;

    function _() {
        x && (M = {
            time: l(),
            event: 4,
            data: {
                visible: N.visible,
                docWidth: N.docWidth,
                docHeight: N.docHeight,
                screenWidth: N.screenWidth,
                screenHeight: N.screenHeight,
                scrollX: N.scrollX,
                scrollY: N.scrollY,
                pointerX: N.pointerX,
                pointerY: N.pointerY,
                activityTime: N.activityTime,
                scrollTime: N.scrollTime,
                pointerTime: N.pointerTime,
                moveX: N.moveX,
                moveY: N.moveY,
                moveTime: N.moveTime,
                downX: N.downX,
                downY: N.downY,
                downTime: N.downTime,
                upX: N.upX,
                upY: N.upY,
                upTime: N.upTime,
                pointerPrevX: N.pointerPrevX,
                pointerPrevY: N.pointerPrevY,
                pointerPrevTime: N.pointerPrevTime
            }
        }), N = N || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: void 0,
            moveX: void 0,
            moveY: void 0,
            moveTime: void 0,
            downX: void 0,
            downY: void 0,
            downTime: void 0,
            upX: void 0,
            upY: void 0,
            upTime: void 0,
            pointerPrevX: void 0,
            pointerPrevY: void 0,
            pointerPrevTime: void 0
        }
    }

    function I(t, e, n, a) {
        switch (t) {
            case 8:
                N.docWidth = e, N.docHeight = n;
                break;
            case 11:
                N.screenWidth = e, N.screenHeight = n;
                break;
            case 10:
                N.scrollX = e, N.scrollY = n, N.scrollTime = a;
                break;
            case 12:
                N.moveX = e, N.moveY = n, N.moveTime = a, N.pointerPrevX = N.pointerX, N.pointerPrevY = N.pointerY, N.pointerPrevTime = N.pointerTime, N.pointerX = e, N.pointerY = n, N.pointerTime = a;
                break;
            case 13:
                N.downX = e, N.downY = n, N.downTime = a, N.pointerPrevX = N.pointerX, N.pointerPrevY = N.pointerY, N.pointerPrevTime = N.pointerTime, N.pointerX = e, N.pointerY = n, N.pointerTime = a;
                break;
            case 14:
                N.upX = e, N.upY = n, N.upTime = a, N.pointerPrevX = N.pointerX, N.pointerPrevY = N.pointerY, N.pointerPrevTime = N.pointerTime, N.pointerX = e, N.pointerY = n, N.pointerTime = a;
                break;
            default:
                N.pointerPrevX = N.pointerX, N.pointerPrevY = N.pointerY, N.pointerPrevTime = N.pointerTime, N.pointerX = e, N.pointerY = n, N.pointerTime = a
        }
        x = !0
    }

    function C(t) {
        N.activityTime = t
    }

    function D(t, e) {
        N.visible = "visible" === e ? 1 : 0, N.visible || C(t), x = !0
    }

    function P() {
        x && ai(4)
    }
    var R = Object.freeze({
            __proto__: null,
            activity: C,
            compute: P,
            reset: _,
            start: function() {
                x = !1, _()
            },
            get state() {
                return M
            },
            stop: function() {
                _()
            },
            track: I,
            visibility: D
        }),
        A = null;

    function X(t, e) {
        so() && t && "string" == typeof t && t.length < 255 && (A = e && "string" == typeof e && e.length < 255 ? {
            key: t,
            value: e
        } : {
            value: t
        }, ai(24))
    }
    var Y, j = null,
        L = null;

    function W(t) {
        t in j || (j[t] = 0), t in L || (L[t] = 0), j[t]++, L[t]++
    }

    function z(t, e) {
        null !== e && (t in j || (j[t] = 0), t in L || (L[t] = 0), j[t] += e, L[t] += e)
    }

    function H(t, e) {
        null !== e && !1 === isNaN(e) && (t in j || (j[t] = 0), (e > j[t] || 0 === j[t]) && (L[t] = e, j[t] = e))
    }

    function q(t, e, n) {
        return window.setTimeout(Fi(t), e, n)
    }

    function U(t) {
        return window.clearTimeout(t)
    }
    var F = 0,
        V = 0,
        B = null;

    function J() {
        B && U(B), B = q(G, V), F = l()
    }

    function G() {
        var t = l();
        Y = {
            gap: t - F
        }, ai(25), Y.gap < 3e5 ? B = q(G, V) : oo && (X("clarity", "suspend"), Ao(), ["mousemove", "touchstart"].forEach((function(t) {
            return Bi(document, t, lo)
        })), ["resize", "scroll", "pageshow"].forEach((function(t) {
            return Bi(window, t, lo)
        })))
    }
    var K = Object.freeze({
            __proto__: null,
            get data() {
                return Y
            },
            reset: J,
            start: function() {
                V = 6e4, F = 0
            },
            stop: function() {
                U(B), F = 0, V = 0
            }
        }),
        Z = null;

    function Q(t, e) {
        if (t in Z) {
            var n = Z[t],
                a = n[n.length - 1];
            e - a[0] > 100 ? Z[t].push([e, 0]) : a[1] = e - a[0]
        } else Z[t] = [
            [e, 0]
        ]
    }

    function $() {
        ai(36)
    }

    function tt() {
        Z = {}
    }
    var et = Object.freeze({
        __proto__: null,
        compute: $,
        get data() {
            return Z
        },
        reset: tt,
        start: function() {
            Z = {}
        },
        stop: function() {
            Z = {}
        },
        track: Q
    });

    function nt(t, e, n, a) {
        return new(n || (n = Promise))((function(r, i) {
            function o(t) {
                try {
                    c(a.next(t))
                } catch (t) {
                    i(t)
                }
            }

            function u(t) {
                try {
                    c(a.throw(t))
                } catch (t) {
                    i(t)
                }
            }

            function c(t) {
                var e;
                t.done ? r(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                    t(e)
                }))).then(o, u)
            }
            c((a = a.apply(t, e || [])).next())
        }))
    }

    function at(t, e) {
        var n, a, r, i, o = {
            label: 0,
            sent: function() {
                if (1 & r[0]) throw r[1];
                return r[1]
            },
            trys: [],
            ops: []
        };
        return i = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this
        }), i;

        function u(u) {
            return function(c) {
                return function(u) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (; i && (i = 0, u[0] && (o = 0)), o;) try {
                        if (n = 1, a && (r = 2 & u[0] ? a.return : u[0] ? a.throw || ((r = a.return) && r.call(a), 0) : a.next) && !(r = r.call(a, u[1])).done) return r;
                        switch (a = 0, r && (u = [2 & u[0], r.value]), u[0]) {
                            case 0:
                            case 1:
                                r = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, a = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!(r = o.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!r || u[1] > r[0] && u[1] < r[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < r[1]) {
                                    o.label = r[1], r = u;
                                    break
                                }
                                if (r && o.label < r[2]) {
                                    o.label = r[2], o.ops.push(u);
                                    break
                                }
                                r[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = e.call(t, o)
                    } catch (t) {
                        u = [6, t], a = 0
                    } finally {
                        n = r = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, c])
            }
        }
    }
    var rt = "CompressionStream" in window;

    function it(t) {
        return nt(this, void 0, void 0, (function() {
            var e, n;
            return at(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 3, , 4]), rt ? (e = new ReadableStream({
                            start: function(e) {
                                return nt(this, void 0, void 0, (function() {
                                    return at(this, (function(n) {
                                        return e.enqueue(t), e.close(), [2]
                                    }))
                                }))
                            }
                        }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip")), n = Uint8Array.bind, [4, ot(e)]) : [3, 2];
                    case 1:
                        return [2, new(n.apply(Uint8Array, [void 0, a.sent()]))];
                    case 2:
                        return [3, 4];
                    case 3:
                        return a.sent(), [3, 4];
                    case 4:
                        return [2, null]
                }
            }))
        }))
    }

    function ot(t) {
        return nt(this, void 0, void 0, (function() {
            var e, n, a, r, i;
            return at(this, (function(o) {
                switch (o.label) {
                    case 0:
                        e = t.getReader(), n = [], a = !1, r = [], o.label = 1;
                    case 1:
                        return a ? [3, 3] : [4, e.read()];
                    case 2:
                        return i = o.sent(), a = i.done, r = i.value, a ? [2, n] : (n.push.apply(n, r), [3, 1]);
                    case 3:
                        return [2, n]
                }
            }))
        }))
    }
    var ut = null;

    function ct(t, e) {
        lt(t, "string" == typeof e ? [e] : e)
    }

    function st(t, e, n, a) {
        return void 0 === e && (e = null), void 0 === n && (n = null), void 0 === a && (a = null), nt(this, void 0, void 0, (function() {
            var r, i;
            return at(this, (function(o) {
                switch (o.label) {
                    case 0:
                        return i = {}, [4, pt(t)];
                    case 1:
                        return i.userId = o.sent(), i.userHint = a || ((u = t) && u.length >= 5 ? "".concat(u.substring(0, 2)).concat(O(u.substring(2), "*", "*")) : O(u, "*", "*")), lt("userId", [(r = i).userId]), lt("userHint", [r.userHint]), lt("userType", [ht(t)]), e && (lt("sessionId", [e]), r.sessionId = e), n && (lt("pageId", [n]), r.pageId = n), [2, r]
                }
                var u
            }))
        }))
    }

    function lt(t, e) {
        if (so() && t && e && "string" == typeof t && t.length < 255) {
            for (var n = (t in ut ? ut[t] : []), a = 0; a < e.length; a++) "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
            ut[t] = n
        }
    }

    function dt() {
        ai(34)
    }

    function ft() {
        ut = {}
    }

    function pt(t) {
        return nt(this, void 0, void 0, (function() {
            var e;
            return at(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return n.trys.push([0, 4, , 5]), crypto && t ? [4, crypto.subtle.digest("SHA-256", (new TextEncoder).encode(t))] : [3, 2];
                    case 1:
                        return e = n.sent(), [2, Array.prototype.map.call(new Uint8Array(e), (function(t) {
                            return ("00" + t.toString(16)).slice(-2)
                        })).join("")];
                    case 2:
                        return [2, ""];
                    case 3:
                        return [3, 5];
                    case 4:
                        return n.sent(), [2, ""];
                    case 5:
                        return [2]
                }
            }))
        }))
    }

    function ht(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }
    var vt = Object.freeze({
            __proto__: null,
            compute: dt,
            get data() {
                return ut
            },
            identify: st,
            reset: ft,
            set: ct,
            start: function() {
                ft()
            },
            stop: function() {
                ft()
            }
        }),
        gt = {},
        mt = new Set,
        yt = {},
        bt = {},
        wt = {},
        kt = {};

    function St(t) {
        try {
            var e = t && t.length > 0 ? t.split(/ (.*)/) : [""],
                n = e[0].split(/\|(.*)/),
                a = parseInt(n[0]),
                r = n.length > 1 ? n[1] : "",
                i = e.length > 1 ? JSON.parse(e[1]) : {};
            for (var o in yt[a] = {}, bt[a] = {}, wt[a] = {}, kt[a] = r, i) {
                var u = parseInt(o),
                    c = i[o],
                    s = 2;
                switch (c.startsWith("~") ? s = 0 : c.startsWith("!") && (s = 4), s) {
                    case 0:
                        var l = c.slice(1);
                        yt[a][u] = Nt(l);
                        break;
                    case 2:
                        bt[a][u] = c;
                        break;
                    case 4:
                        var d = c.slice(1);
                        wt[a][u] = d
                }
            }
        } catch (t) {
            Pr(8, 1, t ? t.name : null)
        }
    }

    function Ot(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function Tt() {
        try {
            for (var t in yt) {
                var e = parseInt(t);
                if ("" == kt[e] || document.querySelector(kt[e])) {
                    var n = yt[e];
                    for (var a in n) {
                        var r = parseInt(a),
                            i = (m = xt(Ot(n[r]))) ? JSON.stringify(m).slice(0, 1e4) : m;
                        i && Mt(e, r, i)
                    }
                    var o = bt[e];
                    for (var u in o) {
                        var c = !1,
                            s = parseInt(u),
                            l = o[s];
                        l.startsWith("@") && (c = !0, l = l.slice(1));
                        var d = document.querySelectorAll(l);
                        if (d) {
                            var p = Array.from(d).map((function(t) {
                                return t.textContent
                            })).join("<SEP>");
                            Mt(e, s, (c ? f(p).trim() : p).slice(0, 1e4))
                        }
                    }
                    var h = wt[e];
                    for (var v in h) {
                        var g = parseInt(v);
                        Mt(e, g, Ra(h[g]).trim().slice(0, 1e4))
                    }
                }
            }
            mt.size > 0 && ai(40)
        } catch (t) {
            Pr(5, 1, t ? t.name : null)
        }
        var m
    }

    function Et() {
        mt.clear()
    }

    function Mt(t, e, n) {
        var a, r = !1;
        t in gt || (gt[t] = {}, r = !0), a = wt[t], 0 == Object.keys(a).length || e in gt[t] && gt[t][e] == n || (r = !0), gt[t][e] = n, r && mt.add(t)
    }

    function Nt(t) {
        for (var e = [], n = t.split("."); n.length > 0;) {
            var a = n.shift(),
                r = a.indexOf("["),
                i = a.indexOf("{"),
                o = a.indexOf("}");
            e.push({
                name: r > 0 ? a.slice(0, r) : i > 0 ? a.slice(0, i) : a,
                type: r > 0 ? 1 : i > 0 ? 2 : 3,
                condition: i > 0 ? a.slice(i + 1, o) : null
            })
        }
        return e
    }

    function xt(t, e) {
        if (void 0 === e && (e = window), 0 == t.length) return e;
        var n, a = t.shift();
        if (e && e[a.name]) {
            var r = e[a.name];
            if (1 !== a.type && _t(r, a.condition)) n = xt(t, r);
            else if (Array.isArray(r)) {
                for (var i = [], o = 0, u = r; o < u.length; o++) {
                    var c = u[o];
                    if (_t(c, a.condition)) {
                        var s = xt(t, c);
                        s && i.push(s)
                    }
                }
                n = i
            }
            return n
        }
        return null
    }

    function _t(t, e) {
        if (e) {
            var n = e.split(":");
            return n.length > 1 ? t[n[0]] == n[1] : t[n[0]]
        }
        return !0
    }
    var It = null;

    function Ct(t) {
        try {
            if (!It) return;
            var e = function(t) {
                try {
                    return JSON.parse(t)
                } catch (t) {
                    return []
                }
            }(t);
            e.forEach((function(t) {
                It(t)
            }))
        } catch (t) {}
    }
    var Dt = [R, r, vt, a, et, i, o, e, K, n, Object.freeze({
        __proto__: null,
        clone: Ot,
        compute: Tt,
        data: gt,
        keys: mt,
        reset: Et,
        start: function() {
            Et()
        },
        stop: function() {
            Et()
        },
        trigger: St,
        update: Mt
    })];

    function Pt() {
        j = {}, L = {}, W(5), Dt.forEach((function(t) {
            return Fi(t.start)()
        }))
    }

    function Rt() {
        Dt.slice().reverse().forEach((function(t) {
            return Fi(t.stop)()
        })), j = {}, L = {}
    }

    function At() {
        dt(), P(), vi(), ai(0), $(), ui(), Tt()
    }
    var Xt, Yt = [];

    function jt(t, e, n) {
        u.fraud && null !== t && n && n.length >= 5 && (Xt = {
            id: t,
            target: e,
            checksum: f(n, 28)
        }, Yt.indexOf(Xt.checksum) < 0 && (Yt.push(Xt.checksum), Ir(41)))
    }
    var Lt = [];

    function Wt(t) {
        Wt.dn = 5;
        var e = ar(t);
        if (e) {
            var n = e.value,
                a = n && n.length >= 5 && u.fraud && -1 === "password,secret,pass,social,ssn,code,hidden".indexOf(e.type) ? f(n, 28) : "";
            Lt.push({
                time: l(t),
                event: 42,
                data: {
                    target: ar(t),
                    type: e.type,
                    value: n,
                    checksum: a
                }
            }), zr(ir.bind(this, 42))
        }
    }

    function zt() {
        Lt = []
    }

    function Ht(t) {
        var e = {
            x: 0,
            y: 0
        };
        if (t && t.offsetParent)
            do {
                var n = t.offsetParent,
                    a = null === n ? _a(t.ownerDocument) : null;
                e.x += t.offsetLeft, e.y += t.offsetTop, t = a || n
            } while (t);
        return e
    }
    var qt = ["input", "textarea", "radio", "button", "canvas", "select"],
        Ut = [];

    function Ft(t) {
        Bi(t, "click", Vt.bind(this, 9, t), !0)
    }

    function Vt(t, e, n) {
        Vt.dn = 6;
        var a = _a(e),
            r = a ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = Ht(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        var c = ar(n),
            s = function(t) {
                for (; t && t !== document;) {
                    if (t.nodeType === Node.ELEMENT_NODE) {
                        var e = t;
                        if ("A" === e.tagName) return e
                    }
                    t = t.parentNode
                }
                return null
            }(c),
            d = function(t) {
                var e = null,
                    n = document.documentElement;
                if ("function" == typeof t.getBoundingClientRect) {
                    var a = t.getBoundingClientRect();
                    a && a.width > 0 && a.height > 0 && (e = {
                        x: Math.floor(a.left + ("pageXOffset" in window ? window.pageXOffset : n.scrollLeft)),
                        y: Math.floor(a.top + ("pageYOffset" in window ? window.pageYOffset : n.scrollTop)),
                        w: Math.floor(a.width),
                        h: Math.floor(a.height)
                    })
                }
                return e
            }(c);
        0 === n.detail && d && (i = Math.round(d.x + d.w / 2), o = Math.round(d.y + d.h / 2));
        var f = d ? Math.max(Math.floor((i - d.x) / d.w * 32767), 0) : 0,
            p = d ? Math.max(Math.floor((o - d.y) / d.h * 32767), 0) : 0;
        if (null !== i && null !== o) {
            var h = function(t) {
                var e = null,
                    n = !1;
                if (t) {
                    var a = t.textContent || String(t.value || "") || t.alt;
                    if (a) {
                        var r = a.replace(/\s+/g, " ").trim();
                        n = (e = r.substring(0, 25)).length === r.length
                    }
                }
                return {
                    text: e,
                    isFullText: n ? 1 : 0
                }
            }(c);
            Ut.push({
                time: l(n),
                event: t,
                data: {
                    target: c,
                    x: i,
                    y: o,
                    eX: f,
                    eY: p,
                    button: n.button,
                    reaction: Bt(c),
                    context: Jt(s),
                    text: h.text,
                    link: s ? s.href : null,
                    hash: null,
                    trust: n.isTrusted ? 1 : 0,
                    isFullText: h.isFullText
                }
            }), zr(ir.bind(this, t))
        }
    }

    function Bt(t) {
        if (t.nodeType === Node.ELEMENT_NODE) {
            var e = t.tagName.toLowerCase();
            if (qt.indexOf(e) >= 0) return 0
        }
        return 1
    }

    function Jt(t) {
        if (t && t.hasAttribute("target")) switch (t.getAttribute("target")) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function Gt() {
        Ut = []
    }
    var Kt = [];

    function Zt(t, e) {
        Zt.dn = 7, Kt.push({
            time: l(e),
            event: 38,
            data: {
                target: ar(e),
                action: t
            }
        }), zr(ir.bind(this, 38))
    }

    function Qt() {
        Kt = []
    }
    var $t = null,
        te = [];

    function ee(t) {
        ee.dn = 9;
        var e = ar(t),
            n = Ya(e);
        if (e && e.type && n) {
            var a = e.value,
                r = e.type;
            switch (e.type) {
                case "radio":
                case "checkbox":
                    a = e.checked ? "true" : "false"
            }
            var i = {
                target: e,
                value: a,
                type: r
            };
            te.length > 0 && te[te.length - 1].data.target === i.target && te.pop(), te.push({
                time: l(t),
                event: 27,
                data: i
            }), U($t), $t = q(ne, 1e3, 27)
        }
    }

    function ne(t) {
        zr(ir.bind(this, t))
    }

    function ae() {
        te = []
    }
    var re, ie = [],
        oe = null,
        ue = !1,
        ce = 0,
        se = new Set;

    function le(t, e, n) {
        le.dn = 10;
        var a = _a(e),
            r = a ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = Ht(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        null !== i && null !== o && fe({
            time: l(n),
            event: t,
            data: {
                target: ar(n),
                x: i,
                y: o
            }
        })
    }

    function de(t, e, n) {
        de.dn = 11;
        var a = _a(e),
            r = a ? a.contentDocument.documentElement : document.documentElement,
            i = n.changedTouches,
            o = l(n);
        if (i)
            for (var u = 0; u < i.length; u++) {
                var c = i[u],
                    s = "clientX" in c ? Math.round(c.clientX + r.scrollLeft) : null,
                    d = "clientY" in c ? Math.round(c.clientY + r.scrollTop) : null;
                s = s && a ? s + Math.round(a.offsetLeft) : s, d = d && a ? d + Math.round(a.offsetTop) : d;
                var f = "identifier" in c ? c.identifier : void 0;
                switch (t) {
                    case 17:
                        0 === se.size && (ue = !0, ce = f), se.add(f);
                        break;
                    case 18:
                    case 20:
                        se.delete(f)
                }
                var p = ue && ce === f;
                null !== s && null !== d && fe({
                    time: o,
                    event: t,
                    data: {
                        target: ar(n),
                        x: s,
                        y: d,
                        id: f,
                        isPrimary: p
                    }
                }), 20 !== t && 18 !== t || ce === f && (ue = !1)
            }
    }

    function fe(t) {
        switch (t.event) {
            case 12:
            case 15:
            case 19:
                var e = ie.length,
                    n = e > 1 ? ie[e - 2] : null;
                n && function(t, e) {
                    var n = t.data.x - e.data.x,
                        a = t.data.y - e.data.y,
                        r = Math.sqrt(n * n + a * a),
                        i = e.time - t.time,
                        o = e.data.target === t.data.target,
                        u = void 0 === e.data.id || e.data.id === t.data.id;
                    return e.event === t.event && o && r < 20 && i < 25 && u
                }(n, t) && ie.pop(), ie.push(t), U(oe), oe = q(pe, 500, t.event);
                break;
            default:
                ie.push(t), pe(t.event)
        }
    }

    function pe(t) {
        zr(ir.bind(this, t))
    }

    function he() {
        ie = []
    }
    var ve = null,
        ge = !1;

    function me() {
        me.dn = 12;
        var t = document.documentElement;
        re = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, window.innerWidth) : window.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, window.innerHeight) : window.innerHeight
        }, ge ? (U(ve), ve = q(ye, 500, 11)) : (ir(11), ge = !0)
    }

    function ye(t) {
        zr(ir.bind(this, t))
    }

    function be() {
        re = null, U(ve)
    }
    var we = [],
        ke = null,
        Se = null,
        Oe = null;

    function Te(t) {
        void 0 === t && (t = null), Te.dn = 13;
        var e = window,
            n = document.documentElement,
            a = t ? ar(t) : n;
        if (a && a.nodeType === Node.DOCUMENT_NODE) {
            var r = _a(a);
            e = r ? r.contentWindow : e, a = n = a.documentElement
        }
        var i = a === n && "pageXOffset" in e ? Math.round(e.pageXOffset) : Math.round(a.scrollLeft),
            o = a === n && "pageYOffset" in e ? Math.round(e.pageYOffset) : Math.round(a.scrollTop),
            u = window.innerWidth,
            c = window.innerHeight,
            s = u / 3,
            d = u > c ? .15 * c : .2 * c,
            f = c - d,
            p = Ee(s, d),
            h = Ee(s, f),
            v = {
                time: l(t),
                event: 10,
                data: {
                    target: a,
                    x: i,
                    y: o,
                    top: p,
                    bottom: h
                }
            };
        if (null === t && 0 === i && 0 === o || null === i || null === o) return ke = p, void(Se = h);
        var g = we.length,
            m = g > 1 ? we[g - 2] : null;
        m && function(t, e) {
            var n = t.data.x - e.data.x,
                a = t.data.y - e.data.y;
            return n * n + a * a < 400 && e.time - t.time < 25
        }(m, v) && we.pop(), we.push(v), U(Oe), Oe = q(Me, 500, 10)
    }

    function Ee(t, e) {
        var n, a, r;
        return "caretPositionFromPoint" in document ? r = null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n ? void 0 : n.offsetNode : "caretRangeFromPoint" in document && (r = null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a ? void 0 : a.startContainer), r || (r = document.elementFromPoint(t, e)), r && r.nodeType === Node.TEXT_NODE && (r = r.parentNode), r
    }

    function Me(t) {
        zr(ir.bind(this, t))
    }

    function Ne() {
        var t, e;
        if (Ne.dn = 14, ke) {
            var n = rr(ke, null);
            hi(31, null === (t = null == n ? void 0 : n.hash) || void 0 === t ? void 0 : t.join("."))
        }
        if (Se) {
            var a = rr(Se, null);
            hi(32, null === (e = null == a ? void 0 : a.hash) || void 0 === e ? void 0 : e.join("."))
        }
    }
    var xe = null,
        _e = null,
        Ie = null;

    function Ce(t) {
        Ce.dn = 15;
        var e = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
        if (null !== e && !(null === e.anchorNode && null === e.focusNode || e.anchorNode === e.focusNode && e.anchorOffset === e.focusOffset)) {
            var n = xe.start ? xe.start : null;
            null !== _e && null !== xe.start && n !== e.anchorNode && (U(Ie), De(21)), xe = {
                start: e.anchorNode,
                startOffset: e.anchorOffset,
                end: e.focusNode,
                endOffset: e.focusOffset
            }, _e = e, U(Ie), Ie = q(De, 500, 21)
        }
    }

    function De(t) {
        zr(ir.bind(this, t))
    }

    function Pe() {
        _e = null, xe = {
            start: 0,
            startOffset: 0,
            end: 0,
            endOffset: 0
        }
    }
    var Re, Ae, Xe = [];

    function Ye(t) {
        Ye.dn = 16, Xe.push({
            time: l(t),
            event: 39,
            data: {
                target: ar(t)
            }
        }), zr(ir.bind(this, 39))
    }

    function je() {
        Xe = []
    }

    function Le(t) {
        Le.dn = 17, Re = {
            name: t.type,
            persisted: t.persisted ? 1 : 0
        }, ir(26, l(t)), Ao()
    }

    function We() {
        Re = null
    }

    function ze(t) {
        void 0 === t && (t = null), ze.dn = 18, Ae = {
            visible: "visibilityState" in document ? document.visibilityState : "default"
        }, ir(28, l(t))
    }

    function He() {
        Ae = null
    }

    function qe(t) {
        ! function(t) {
            var e = _a(t);
            Bi(e ? e.contentWindow : t === document ? window : t, "scroll", Te, !0)
        }(t), t.nodeType === Node.DOCUMENT_NODE && (Ft(t), function(t) {
            Bi(t, "cut", Zt.bind(this, 0), !0), Bi(t, "copy", Zt.bind(this, 1), !0), Bi(t, "paste", Zt.bind(this, 2), !0)
        }(t), function(t) {
            Bi(t, "mousedown", le.bind(this, 13, t), !0), Bi(t, "mouseup", le.bind(this, 14, t), !0), Bi(t, "mousemove", le.bind(this, 12, t), !0), Bi(t, "wheel", le.bind(this, 15, t), !0), Bi(t, "dblclick", le.bind(this, 16, t), !0), Bi(t, "touchstart", de.bind(this, 17, t), !0), Bi(t, "touchend", de.bind(this, 18, t), !0), Bi(t, "touchmove", de.bind(this, 19, t), !0), Bi(t, "touchcancel", de.bind(this, 20, t), !0)
        }(t), function(t) {
            Bi(t, "input", ee, !0)
        }(t), function(t) {
            Bi(t, "selectstart", Ce.bind(this, t), !0), Bi(t, "selectionchange", Ce.bind(this, t), !0)
        }(t), function(t) {
            Bi(t, "change", Wt, !0)
        }(t), function(t) {
            Bi(t, "submit", Ye, !0)
        }(t))
    }
    var Ue = Object.freeze({
        __proto__: null,
        observe: qe,
        start: function t() {
            t.dn = 8, or = [], cr(), Gt(), Qt(), he(), ae(), ge = !1, Bi(window, "resize", me), me(), Bi(document, "visibilitychange", ze), ze(), we = [], Te(), Pe(), zt(), je(), Bi(window, "pagehide", Le)
        },
        stop: function() {
            or = [], cr(), Gt(), Qt(), U(oe), ie.length > 0 && pe(ie[ie.length - 1].event), U($t), ae(), be(), He(), U(Oe), we = [], ke = null, Se = null, Pe(), U(Ie), zt(), je(), We()
        }
    });
    var Fe = [],
        Ve = [],
        Be = "claritySheetId",
        Je = {},
        Ge = {},
        Ke = [],
        Ze = [];

    function Qe(t) {
        u.lean && u.lite || null == t || (t.clarityOverrides = t.clarityOverrides || {}, t.CSSStyleSheet && t.CSSStyleSheet.prototype && (void 0 === t.clarityOverrides.replace && (t.clarityOverrides.replace = t.CSSStyleSheet.prototype.replace, t.CSSStyleSheet.prototype.replace = function() {
            return so() && Ze.indexOf(this[Be]) > -1 && nn(l(), this[Be], 1, arguments[0]), t.clarityOverrides.replace.apply(this, arguments)
        }), void 0 === t.clarityOverrides.replaceSync && (t.clarityOverrides.replaceSync = t.CSSStyleSheet.prototype.replaceSync, t.CSSStyleSheet.prototype.replaceSync = function() {
            return so() && Ze.indexOf(this[Be]) > -1 && nn(l(), this[Be], 2, arguments[0]), t.clarityOverrides.replaceSync.apply(this, arguments)
        })))
    }

    function $e() {
        Qe(window)
    }

    function tn(t, e) {
        if ((!u.lean || !u.lite) && (-1 === Ke.indexOf(t) && (Ke.push(t), t.defaultView && Qe(t.defaultView)), e = e || l(), null == t ? void 0 : t.adoptedStyleSheets)) {
            for (var n = [], a = 0, r = t.adoptedStyleSheets; a < r.length; a++) {
                var i = r[a];
                i[Be] && -1 !== Ze.indexOf(i[Be]) || (i[Be] = Di(), Ze.push(i[Be]), nn(e, i[Be], 0), nn(e, i[Be], 2, ta(i))), n.push(i[Be])
            }
            var o = Ea(t, !0);
            Je[o] || (Je[o] = []),
                function(t, e) {
                    if (t.length !== e.length) return !1;
                    return t.every((function(t, n) {
                        return t === e[n]
                    }))
                }(n, Je[o]) || (! function(t, e, n, a) {
                    Ve.push({
                        time: t,
                        event: 45,
                        data: {
                            id: e,
                            operation: n,
                            newIds: a
                        }
                    }), bn(45)
                }(e, t == document ? -1 : Ea(t), 3, n), Je[o] = n, Ge[o] = e)
        }
    }

    function en() {
        Ve = [], Fe = []
    }

    function nn(t, e, n, a) {
        Fe.push({
            time: t,
            event: 46,
            data: {
                id: e,
                operation: n,
                cssRules: a
            }
        }), bn(46)
    }
    var an, rn = [],
        on = null,
        un = null,
        cn = null,
        sn = null,
        ln = null,
        dn = null,
        fn = "clarityAnimationId",
        pn = "clarityOperationCount",
        hn = 20;

    function vn() {
        rn = []
    }

    function gn(t, e, n, a, r, i, o) {
        rn.push({
            time: t,
            event: 44,
            data: {
                id: e,
                operation: n,
                keyFrames: a,
                timing: r,
                targetId: i,
                timeline: o
            }
        }), bn(44)
    }

    function mn(t, e) {
        null === t && (t = Animation.prototype[e], Animation.prototype[e] = function() {
            return yn(this, e), t.apply(this, arguments)
        })
    }

    function yn(t, e) {
        if (so()) {
            var n = t.effect,
                a = Ea(n.target);
            if (null !== a && n.getKeyframes && n.getTiming) {
                if (!t[fn]) {
                    t[fn] = Di(), t[pn] = 0;
                    var r = n.getKeyframes(),
                        i = n.getTiming();
                    gn(l(), t[fn], 0, JSON.stringify(r), JSON.stringify(i), a)
                }
                if (t[pn]++ < hn) {
                    var o = null;
                    switch (e) {
                        case "play":
                            o = 1;
                            break;
                        case "pause":
                            o = 2;
                            break;
                        case "cancel":
                            o = 3;
                            break;
                        case "finish":
                            o = 4;
                            break;
                        case "commitStyles":
                            o = 5
                    }
                    o && gn(l(), t[fn], o)
                }
            }
        }
    }

    function bn(t, e, n) {
        return void 0 === e && (e = null), void 0 === n && (n = null), nt(this, void 0, void 0, (function() {
            var a, r, i, o, c, s, d, f, p, h, v, g, m, y, w, k, S, O, T, E, M, N, x, _, D, P, R, A, X;
            return at(this, (function(Y) {
                switch (Y.label) {
                    case 0:
                        switch (a = n || l(), r = [a, t], t) {
                            case 8:
                                return [3, 1];
                            case 7:
                                return [3, 2];
                            case 45:
                            case 46:
                                return [3, 3];
                            case 44:
                                return [3, 4];
                            case 5:
                            case 6:
                                return [3, 5]
                        }
                        return [3, 12];
                    case 1:
                        return i = an, r.push(i.width), r.push(i.height), I(t, i.width, i.height), kr(r), [3, 12];
                    case 2:
                        for (o = 0, c = Ua; o < c.length; o++) s = c[o], (r = [s.time, 7]).push(s.data.id), r.push(s.data.interaction), r.push(s.data.visibility), r.push(s.data.name), kr(r);
                        return nr(), [3, 12];
                    case 3:
                        for (d = 0, f = Ve; d < f.length; d++) m = f[d], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.newIds), kr(r);
                        for (p = 0, h = Fe; p < h.length; p++) m = h[p], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.cssRules), kr(r);
                        return en(), [3, 12];
                    case 4:
                        for (v = 0, g = rn; v < g.length; v++) m = g[v], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.keyFrames), r.push(m.data.timing), r.push(m.data.timeline), r.push(m.data.targetId), kr(r);
                        return vn(), [3, 12];
                    case 5:
                        if (2 === qr(e)) return [3, 12];
                        if (!((y = Wa()).length > 0)) return [3, 11];
                        w = 0, k = y, Y.label = 6;
                    case 6:
                        return w < k.length ? (S = k[w], 0 !== (O = qr(e)) ? [3, 8] : [4, Vr(e)]) : [3, 10];
                    case 7:
                        O = Y.sent(), Y.label = 8;
                    case 8:
                        if (2 === O) return [3, 10];
                        for (T = S.data, E = S.metadata.active, M = S.metadata.suspend, N = S.metadata.privacy, x = function(t) {
                                var e = t.metadata.privacy;
                                return "*T" === t.data.tag && !(0 === e || 1 === e)
                            }(S), _ = 0, D = E ? ["tag", "attributes", "value"] : ["tag"]; _ < D.length; _++)
                            if (T[P = D[_]] || "" === T[P]) switch (P) {
                                case "tag":
                                    R = wn(S), A = x ? -1 : 1, r.push(S.id * A), S.parent && E && (r.push(S.parent), S.previous && r.push(S.previous)), r.push(M ? "*M" : T[P]), R && 2 === R.length && r.push("".concat("#").concat(kn(R[0]), ".").concat(kn(R[1])));
                                    break;
                                case "attributes":
                                    for (X in T[P]) void 0 !== T[P][X] && r.push(Sn(X, T[P][X], N));
                                    break;
                                case "value":
                                    jt(S.metadata.fraud, S.id, T[P]), r.push(b(T[P], T.tag, N, x))
                            }
                        Y.label = 9;
                    case 9:
                        return w++, [3, 6];
                    case 10:
                        6 === t && C(a), kr(function(t) {
                            for (var e = [], n = {}, a = 0, r = null, i = 0; i < t.length; i++)
                                if ("string" == typeof t[i]) {
                                    var o = t[i],
                                        u = n[o] || -1;
                                    u >= 0 ? r ? r.push(u) : (r = [u], e.push(r), a++) : (r = null, e.push(o), n[o] = a++)
                                } else r = null, e.push(t[i]), a++;
                            return e
                        }(r), !u.lean), Y.label = 11;
                    case 11:
                        return [3, 12];
                    case 12:
                        return [2]
                }
            }))
        }))
    }

    function wn(t) {
        if (null !== t.metadata.size && 0 === t.metadata.size.length) {
            var e = Aa(t.id);
            if (e) return [Math.floor(100 * e.offsetWidth), Math.floor(100 * e.offsetHeight)]
        }
        return t.metadata.size
    }

    function kn(t) {
        return t.toString(36)
    }

    function Sn(t, e, n) {
        return "".concat(t, "=").concat(b(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }

    function On() {
        an = null
    }

    function Tn() {
        Tn.dn = 19;
        var t = document.body,
            e = document.documentElement,
            n = t ? t.clientWidth : null,
            a = t ? t.scrollWidth : null,
            r = t ? t.offsetWidth : null,
            i = e ? e.clientWidth : null,
            o = e ? e.scrollWidth : null,
            u = e ? e.offsetWidth : null,
            c = Math.max(n, a, r, i, o, u),
            s = t ? t.clientHeight : null,
            l = t ? t.scrollHeight : null,
            d = t ? t.offsetHeight : null,
            f = e ? e.clientHeight : null,
            p = e ? e.scrollHeight : null,
            h = e ? e.offsetHeight : null,
            v = Math.max(s, l, d, f, p, h);
        null !== an && c === an.width && v === an.height || null === c || null === v || (an = {
            width: c,
            height: v
        }, bn(8))
    }

    function En(t, e, n, a) {
        return nt(this, void 0, void 0, (function() {
            var r, i, o, u, c;
            return at(this, (function(s) {
                switch (s.label) {
                    case 0:
                        r = [t], s.label = 1;
                    case 1:
                        if (!(r.length > 0)) return [3, 4];
                        for (i = r.shift(), o = i.firstChild; o;) r.push(o), o = o.nextSibling;
                        return 0 !== (u = qr(e)) ? [3, 3] : [4, Vr(e)];
                    case 2:
                        u = s.sent(), s.label = 3;
                    case 3:
                        return 2 === u ? [3, 4] : ((c = Kn(i, n, a)) && r.push(c), [3, 1]);
                    case 4:
                        return [2]
                }
            }))
        }))
    }
    var Mn = new Set,
        Nn = [],
        xn = {},
        _n = [],
        In = null,
        Cn = null,
        Dn = null,
        Pn = {},
        Rn = new WeakMap,
        An = ["data-google-query-id", "data-load-complete", "data-google-container-id"];

    function Xn() {
        Xn.dn = 21, Mn = new Set, _n = [], In = null, Dn = 0, Pn = {}, Rn = new WeakMap, Un(window)
    }

    function Yn(t) {
        Yn.dn = 22;
        var e = l();
        Q(6, e), Nn.push({
            time: e,
            mutations: t
        }), zr(Ln, 1).then((function() {
            q(Tn), Fi(Qa)()
        }))
    }

    function jn(t, e, n, a) {
        return nt(this, void 0, void 0, (function() {
            var r, i, o;
            return at(this, (function(c) {
                switch (c.label) {
                    case 0:
                        return 0 !== (r = qr(t)) ? [3, 2] : [4, Vr(t)];
                    case 1:
                        r = c.sent(), c.label = 2;
                    case 2:
                        if (2 === r) return [2];
                        switch (i = e.target, o = u.throttleDom ? function(t, e, n, a) {
                            var r = t.target ? Ya(t.target.parentNode) : null;
                            if (r && "HTML" !== r.data.tag) {
                                var i = a > Dn,
                                    o = Ya(t.target),
                                    u = o && o.selector ? o.selector.join() : t.target.nodeName,
                                    c = [r.selector ? r.selector.join() : "", u, t.attributeName, Wn(t.addedNodes), Wn(t.removedNodes)].join();
                                Pn[c] = c in Pn ? Pn[c] : [0, n];
                                var s = Pn[c];
                                if (!1 === i && s[0] >= 10 && zn(s[2], 2, e, a), s[0] = i ? s[1] === n ? s[0] : s[0] + 1 : 1, s[1] = n, s[0] >= 10) return s[2] = t.removedNodes, n > a + 3e3 ? t.type : (xn[c] = {
                                    mutation: t,
                                    timestamp: a
                                }, "throttle")
                            }
                            return t.type
                        }(e, t, n, a) : e.type, o && i && i.ownerDocument && Ta(i.ownerDocument), o && i && i.nodeType == Node.DOCUMENT_FRAGMENT_NODE && i.host && Ta(i), o) {
                            case "attributes":
                                An.indexOf(e.attributeName) < 0 && Kn(i, 3, a);
                                break;
                            case "characterData":
                                Kn(i, 4, a);
                                break;
                            case "childList":
                                zn(e.addedNodes, 1, t, a), zn(e.removedNodes, 2, t, a)
                        }
                        return [2]
                }
            }))
        }))
    }

    function Ln() {
        return nt(this, void 0, void 0, (function() {
            var t, e, n, a, r, i, o, u, c, s, d;
            return at(this, (function(f) {
                switch (f.label) {
                    case 0:
                        Ur(t = {
                            id: Ei(),
                            cost: 3
                        }), f.label = 1;
                    case 1:
                        if (!(Nn.length > 0)) return [3, 7];
                        e = Nn.shift(), n = l(), a = 0, r = e.mutations, f.label = 2;
                    case 2:
                        return a < r.length ? (i = r[a], [4, jn(t, i, n, e.time)]) : [3, 5];
                    case 3:
                        f.sent(), f.label = 4;
                    case 4:
                        return a++, [3, 2];
                    case 5:
                        return [4, bn(6, t, e.time)];
                    case 6:
                        return f.sent(), [3, 1];
                    case 7:
                        o = !1, u = 0, c = Object.keys(xn), f.label = 8;
                    case 8:
                        return u < c.length ? (s = c[u], d = xn[s], delete xn[s], [4, jn(t, d.mutation, l(), d.timestamp)]) : [3, 11];
                    case 9:
                        f.sent(), o = !0, f.label = 10;
                    case 10:
                        return u++, [3, 8];
                    case 11:
                        return Object.keys(xn).length > 0 && function() {
                            Cn && U(Cn);
                            Cn = q((function() {
                                zr(Ln, 1)
                            }), 33)
                        }(), 0 === Object.keys(xn).length && o ? [4, bn(6, t, l())] : [3, 13];
                    case 12:
                        f.sent(), f.label = 13;
                    case 13:
                        return function() {
                            var t = l();
                            Object.keys(Pn).length > 1e4 && (Pn = {}, W(38));
                            for (var e = 0, n = Object.keys(Pn); e < n.length; e++) {
                                var a = n[e];
                                t > Pn[a][1] + 3e4 && delete Pn[a]
                            }
                        }(), Fr(t), [2]
                }
            }))
        }))
    }

    function Wn(t) {
        for (var e = [], n = 0; t && n < t.length; n++) e.push(t[n].nodeName);
        return e.join()
    }

    function zn(t, e, n, a) {
        return nt(this, void 0, void 0, (function() {
            var r, i, o, u;
            return at(this, (function(c) {
                switch (c.label) {
                    case 0:
                        r = t ? t.length : 0, i = 0, c.label = 1;
                    case 1:
                        return i < r ? (o = t[i], 1 !== e ? [3, 2] : (En(o, n, e, a), [3, 5])) : [3, 6];
                    case 2:
                        return 0 !== (u = qr(n)) ? [3, 4] : [4, Vr(n)];
                    case 3:
                        u = c.sent(), c.label = 4;
                    case 4:
                        if (2 === u) return [3, 6];
                        Kn(o, e, a), c.label = 5;
                    case 5:
                        return i++, [3, 1];
                    case 6:
                        return [2]
                }
            }))
        }))
    }

    function Hn(t) {
        return _n.indexOf(t) < 0 && _n.push(t), In && U(In), In = q((function() {
            ! function() {
                for (var t = 0, e = _n; t < e.length; t++) {
                    var n = e[t];
                    if (n) {
                        var a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE;
                        if (a && La(n)) continue;
                        qn(n, a ? "childList" : "characterData")
                    }
                }
                _n = []
            }()
        }), 33), t
    }

    function qn(t, e) {
        qn.dn = 23, Fi(Yn)([{
            addedNodes: [t],
            attributeName: null,
            attributeNamespace: null,
            nextSibling: null,
            oldValue: null,
            previousSibling: null,
            removedNodes: [],
            target: t,
            type: e
        }])
    }

    function Un(t) {
        if (null != t && (t.clarityOverrides = t.clarityOverrides || {}, void 0 === t.clarityOverrides.InsertRule && (t.clarityOverrides.InsertRule = t.CSSStyleSheet.prototype.insertRule, t.CSSStyleSheet.prototype.insertRule = function() {
                return so() && Hn(this.ownerNode), t.clarityOverrides.InsertRule.apply(this, arguments)
            }), "CSSMediaRule" in t && void 0 === t.clarityOverrides.MediaInsertRule && (t.clarityOverrides.MediaInsertRule = t.CSSMediaRule.prototype.insertRule, t.CSSMediaRule.prototype.insertRule = function() {
                return so() && Hn(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaInsertRule.apply(this, arguments)
            }), void 0 === t.clarityOverrides.DeleteRule && (t.clarityOverrides.DeleteRule = t.CSSStyleSheet.prototype.deleteRule, t.CSSStyleSheet.prototype.deleteRule = function() {
                return so() && Hn(this.ownerNode), t.clarityOverrides.DeleteRule.apply(this, arguments)
            }), "CSSMediaRule" in t && void 0 === t.clarityOverrides.MediaDeleteRule && (t.clarityOverrides.MediaDeleteRule = t.CSSMediaRule.prototype.deleteRule, t.CSSMediaRule.prototype.deleteRule = function() {
                return so() && Hn(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaDeleteRule.apply(this, arguments)
            }), void 0 === t.clarityOverrides.AttachShadow)) {
            t.clarityOverrides.AttachShadow = t.Element.prototype.attachShadow;
            try {
                t.Element.prototype.attachShadow = function() {
                    return so() ? Hn(t.clarityOverrides.AttachShadow.apply(this, arguments)) : t.clarityOverrides.AttachShadow.apply(this, arguments)
                }
            } catch (e) {
                t.clarityOverrides.AttachShadow = null
            }
        }
    }
    var Fn = /[^0-9\.]/g;

    function Vn(t) {
        for (var e = 0, n = Object.keys(t); e < n.length; e++) {
            var a = n[e],
                r = t[a];
            if ("@type" === a && "string" == typeof r) switch (r = (r = r.toLowerCase()).indexOf("article") >= 0 || r.indexOf("posting") >= 0 ? "article" : r) {
                case "article":
                case "recipe":
                    hi(5, t[a]), hi(8, t.creator), hi(18, t.headline);
                    break;
                case "product":
                    hi(5, t[a]), hi(10, t.name), hi(12, t.sku), t.brand && hi(6, t.brand.name);
                    break;
                case "aggregaterating":
                    t.ratingValue && (H(11, Bn(t.ratingValue, 100)), H(18, Bn(t.bestRating)), H(19, Bn(t.worstRating))), H(12, Bn(t.ratingCount)), H(17, Bn(t.reviewCount));
                    break;
                case "offer":
                    hi(7, t.availability), hi(14, t.itemCondition), hi(13, t.priceCurrency), hi(12, t.sku), H(13, Bn(t.price));
                    break;
                case "brand":
                    hi(6, t.name)
            }
            null !== r && "object" == typeof r && Vn(r)
        }
    }

    function Bn(t, e) {
        if (void 0 === e && (e = 1), null !== t) switch (typeof t) {
            case "number":
                return Math.round(t * e);
            case "string":
                return Math.round(parseFloat(t.replace(Fn, "")) * e)
        }
        return null
    }
    var Jn = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label"],
        Gn = /[\r\n]+/g;

    function Kn(e, n, a) {
        var r, i = null;
        if (2 === n && !1 === La(e)) return i;
        0 !== n && e.nodeType === Node.TEXT_NODE && e.parentElement && "STYLE" === e.parentElement.tagName && (e = e.parentNode);
        var o = !1 === La(e) ? "add" : "update",
            u = e.parentElement ? e.parentElement : null,
            c = e.ownerDocument !== document;
        switch (e.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
                u = c && e.parentNode ? _a(e.parentNode) : u;
                var s = e,
                    l = {
                        tag: (c ? "iframe:" : "") + "*D",
                        attributes: {
                            name: s.name ? s.name : "HTML",
                            publicId: s.publicId,
                            systemId: s.systemId
                        }
                    };
                t[o](e, u, l, n);
                break;
            case Node.DOCUMENT_NODE:
                e === document && Ta(document), tn(e, a), Zn(e);
                break;
            case Node.DOCUMENT_FRAGMENT_NODE:
                var d = e;
                if (d.host) {
                    if (Ta(d), "function" === typeof d.constructor && d.constructor.toString().indexOf("[native code]") >= 0) {
                        Zn(d);
                        var f = {
                            tag: "*S",
                            attributes: {
                                style: ""
                            }
                        };
                        t[o](e, d.host, f, n)
                    } else t[o](e, d.host, {
                        tag: "*P",
                        attributes: {}
                    }, n);
                    tn(e, a)
                }
                break;
            case Node.TEXT_NODE:
                if (u = u || e.parentNode, "update" === o || u && La(u) && "STYLE" !== u.tagName && "NOSCRIPT" !== u.tagName) {
                    var p = {
                        tag: "*T",
                        value: e.nodeValue
                    };
                    t[o](e, u, p, n)
                }
                break;
            case Node.ELEMENT_NODE:
                var h = e,
                    v = h.tagName,
                    g = function(t) {
                        var e = {},
                            n = t.attributes;
                        if (n && n.length > 0)
                            for (var a = 0; a < n.length; a++) {
                                var r = n[a].name;
                                Jn.indexOf(r) < 0 && (e[r] = n[a].value)
                            }
                        "INPUT" === t.tagName && !("value" in e) && t.value && (e.value = t.value);
                        return e
                    }(h);
                switch (u = e.parentElement ? e.parentElement : e.parentNode ? e.parentNode : null, "http://www.w3.org/2000/svg" === h.namespaceURI && (v = "svg:" + v), v) {
                    case "HTML":
                        u = c && u ? _a(u) : u;
                        var m = {
                            tag: (c ? "iframe:" : "") + v,
                            attributes: g
                        };
                        t[o](e, u, m, n);
                        break;
                    case "SCRIPT":
                        if ("type" in g && "application/ld+json" === g.type) try {
                            Vn(JSON.parse(h.text.replace(Gn, "")))
                        } catch (t) {}
                        break;
                    case "NOSCRIPT":
                        var y = {
                            tag: v,
                            attributes: {},
                            value: ""
                        };
                        t[o](e, u, y, n);
                        break;
                    case "META":
                        var b = "property" in g ? "property" : "name" in g ? "name" : null;
                        if (b && "content" in g) {
                            var w = g.content;
                            switch (g[b]) {
                                case "og:title":
                                    hi(20, w);
                                    break;
                                case "og:type":
                                    hi(19, w);
                                    break;
                                case "generator":
                                    hi(21, w)
                            }
                        }
                        break;
                    case "HEAD":
                        var k = {
                                tag: v,
                                attributes: g
                            },
                            S = c && (null === (r = e.ownerDocument) || void 0 === r ? void 0 : r.location) ? e.ownerDocument.location : location;
                        k.attributes["*B"] = S.protocol + "//" + S.host + S.pathname, t[o](e, u, k, n);
                        break;
                    case "BASE":
                        var O = Ya(e.parentElement);
                        if (O) {
                            var T = document.createElement("a");
                            T.href = g.href, O.data.attributes["*B"] = T.protocol + "//" + T.host + T.pathname
                        }
                        break;
                    case "STYLE":
                        var E = {
                            tag: v,
                            attributes: g,
                            value: $n(h)
                        };
                        t[o](e, u, E, n);
                        break;
                    case "IFRAME":
                        var M = e,
                            N = {
                                tag: v,
                                attributes: g
                            };
                        xa(M) && (! function(t) {
                            !1 === La(t) && Bi(t, "load", qn.bind(this, t, "childList"), !0)
                        }(M), N.attributes["*O"] = "true", M.contentDocument && M.contentWindow && "loading" !== M.contentDocument.readyState && (i = M.contentDocument)), 2 === n && Qn(M), t[o](e, u, N, n);
                        break;
                    case "LINK":
                        if (wi && "stylesheet" === g.rel) {
                            for (var x in Object.keys(document.styleSheets)) {
                                var _ = document.styleSheets[x];
                                if (_.ownerNode == h) {
                                    var I = {
                                        tag: "STYLE",
                                        attributes: g,
                                        value: ta(_)
                                    };
                                    t[o](e, u, I, n);
                                    break
                                }
                            }
                            break
                        }
                        var C = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, C, n);
                        break;
                    case "VIDEO":
                    case "AUDIO":
                    case "SOURCE":
                        "src" in g && g.src.startsWith("data:") && (g.src = "");
                        var D = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, D, n);
                        break;
                    default:
                        var P = {
                            tag: v,
                            attributes: g
                        };
                        h.shadowRoot && (i = h.shadowRoot), t[o](e, u, P, n)
                }
        }
        return i
    }

    function Zn(t) {
        La(t) || Ki(t) || (! function(t) {
            try {
                var e = c("MutationObserver"),
                    n = e in window ? new window[e](Fi(Yn)) : null;
                n && (n.observe(t, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                }), Rn.set(t, n), Mn.add(n)), t.defaultView && Un(t.defaultView)
            } catch (t) {
                Pr(2, 0, t ? t.name : null)
            }
        }(t), qe(t))
    }

    function Qn(t) {
        Gi(t);
        var e, n, a = Ia(t) || {},
            r = a.doc,
            i = void 0 === r ? null : r,
            o = a.win,
            u = void 0 === o ? null : o;
        u && Gi(u), i && (Gi(i), e = i, (n = Rn.get(e)) && (n.disconnect(), Mn.delete(n), Rn.delete(e)), Ca(t, i))
    }

    function $n(t) {
        var e = t.textContent ? t.textContent.trim() : "",
            n = t.dataset ? Object.keys(t.dataset).length : 0;
        return (0 === e.length || n > 0 || t.id.length > 0) && (e = ta(t.sheet)), e
    }

    function ta(t) {
        var e = "",
            n = null;
        try {
            n = t ? t.cssRules : []
        } catch (t) {
            if (Pr(1, 1, t ? t.name : null), t && "SecurityError" !== t.name) throw t
        }
        if (null !== n)
            for (var a = 0; a < n.length; a++) e += n[a].cssText;
        return e
    }
    var ea = "load,active,fixed,visible,focus,show,collaps,animat".split(","),
        na = {};

    function aa(t, e) {
        var n = t.attributes,
            a = t.prefix ? t.prefix[e] : null,
            r = 0 === e ? "".concat("~").concat(t.position - 1) : ":nth-of-type(".concat(t.position, ")");
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                if (null === a) return "";
                a = "".concat(a).concat(">"), t.tag = 0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag;
                var i = "".concat(a).concat(t.tag).concat(r),
                    o = "id" in n && n.id.length > 0 ? n.id : null,
                    u = "BODY" !== t.tag && "class" in n && n.class.length > 0 ? n.class.trim().split(/\s+/).filter((function(t) {
                        return ra(t)
                    })).join(".") : null;
                if (u && u.length > 0)
                    if (0 === e) {
                        var c = "".concat(function(t) {
                            for (var e = t.split(">"), n = 0; n < e.length; n++) {
                                var a = e[n].indexOf("~"),
                                    r = e[n].indexOf(".");
                                e[n] = e[n].substring(0, r > 0 ? r : a > 0 ? a : e[n].length)
                            }
                            return e.join(">")
                        }(a)).concat(t.tag).concat(".").concat(u);
                        c in na || (na[c] = []), na[c].indexOf(t.id) < 0 && na[c].push(t.id), i = "".concat(c).concat("~").concat(na[c].indexOf(t.id))
                    } else i = "".concat(a).concat(t.tag, ".").concat(u).concat(r);
                return i = o && ra(o) ? "".concat(function(t) {
                    var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("".concat("iframe:").concat("HTML")),
                        a = Math.max(e, n);
                    if (a < 0) return "";
                    return t.substring(0, t.indexOf(">", a) + 1)
                }(a)).concat("#").concat(o) : i, i
        }
    }

    function ra(t) {
        if (!t) return !1;
        if (ea.some((function(e) {
                return t.toLowerCase().indexOf(e) >= 0
            }))) return !1;
        for (var e = 0; e < t.length; e++) {
            var n = t.charCodeAt(e);
            if (n >= 48 && n <= 57) return !1
        }
        return !0
    }
    var ia = 1,
        oa = null,
        ua = [],
        ca = [],
        sa = {},
        la = [],
        da = [],
        fa = [],
        pa = [],
        ha = [],
        va = [],
        ga = null,
        ma = null,
        ya = null,
        ba = null,
        wa = null;

    function ka() {
        Oa(), Ta(document, !0)
    }

    function Sa() {
        Oa()
    }

    function Oa() {
        ia = 1, ua = [], ca = [], sa = {}, la = [], da = [], fa = "address,password,contact".split(","), pa = "password,secret,pass,social,ssn,code,hidden".split(","), ha = "radio,checkbox,range,button,reset,submit".split(","), va = "INPUT,SELECT,TEXTAREA".split(","), oa = new Map, ga = new WeakMap, ma = new WeakMap, ya = new WeakMap, ba = new WeakMap, wa = new WeakMap, na = {}
    }

    function Ta(t, e) {
        void 0 === e && (e = !1);
        try {
            e && u.unmask.forEach((function(t) {
                return t.indexOf("!") < 0 ? da.push(t) : la.push(t.substr(1))
            })), "querySelectorAll" in t && (u.regions.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return Ka(t, "".concat(e[0]))
                }))
            })), u.mask.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return ba.set(t, 3)
                }))
            })), u.checksum.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return wa.set(t, e[0])
                }))
            })), da.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return ba.set(t, 0)
                }))
            })))
        } catch (t) {
            Pr(5, 1, t ? t.name : null)
        }
    }

    function Ea(t, e) {
        if (void 0 === e && (e = !1), null === t) return null;
        var n = ga.get(t);
        return !n && e && (n = ia++, ga.set(t, n)), n || null
    }

    function Ma(t, e, n, a) {
        var r = e ? Ea(e) : null;
        if (e && r || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) {
            var i = Ea(t, !0),
                o = Ha(t),
                c = null,
                s = Za(t) ? i : null,
                l = wa.has(t) ? wa.get(t) : null,
                d = u.content ? 1 : 3;
            r >= 0 && ua[r] && ((c = ua[r]).children.push(i), s = null === s ? c.region : s, l = null === l ? c.metadata.fraud : l, d = c.metadata.privacy), n.attributes && "data-clarity-region" in n.attributes && (Ka(t, n.attributes["data-clarity-region"]), s = i), oa.set(i, t), ua[i] = {
                    id: i,
                    parent: r,
                    previous: o,
                    children: [],
                    data: n,
                    selector: null,
                    hash: null,
                    region: s,
                    metadata: {
                        active: !0,
                        suspend: !1,
                        privacy: d,
                        position: null,
                        fraud: l,
                        size: null
                    }
                },
                function(t, e, n) {
                    var a, r = e.data,
                        i = e.metadata,
                        o = i.privacy,
                        u = r.attributes || {},
                        c = r.tag.toUpperCase();
                    switch (!0) {
                        case va.indexOf(c) >= 0:
                            var s = u.type,
                                l = "",
                                d = ["class", "style"];
                            Object.keys(u).filter((function(t) {
                                return !d.includes(t)
                            })).forEach((function(t) {
                                return l += u[t].toLowerCase()
                            }));
                            var f = pa.some((function(t) {
                                return l.indexOf(t) >= 0
                            }));
                            i.privacy = "INPUT" === c && ha.indexOf(s) >= 0 ? o : f ? 4 : 2;
                            break;
                        case "data-clarity-mask" in u:
                            i.privacy = 3;
                            break;
                        case "data-clarity-unmask" in u:
                            i.privacy = 0;
                            break;
                        case ba.has(t):
                            i.privacy = ba.get(t);
                            break;
                        case wa.has(t):
                            i.privacy = 2;
                            break;
                        case "*T" === c:
                            var p = n && n.data ? n.data.tag : "",
                                h = n && n.selector ? n.selector[1] : "",
                                v = ["STYLE", "TITLE", "svg:style"];
                            i.privacy = v.includes(p) || la.some((function(t) {
                                return h.indexOf(t) >= 0
                            })) ? 0 : o;
                            break;
                        case 1 === o:
                            i.privacy = function(t, e, n) {
                                if (t && e.some((function(e) {
                                        return t.indexOf(e) >= 0
                                    }))) return 2;
                                return n.privacy
                            }(u.class, fa, i);
                            break;
                        case "IMG" === c:
                            (null === (a = u.src) || void 0 === a ? void 0 : a.startsWith("blob:")) && (i.privacy = 3)
                    }
                }(t, ua[i], c), Pa(ua[i]),
                function(t) {
                    if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
                        var e = Aa(t.id);
                        !e || e.complete && 0 !== e.naturalWidth || Bi(e, "load", (function() {
                            e.setAttribute("data-clarity-loaded", "".concat(Di()))
                        })), t.metadata.size = []
                    }
                }(ua[i]), qa(i, a)
        }
    }

    function Na(t, e, n, a) {
        var r = Ea(t),
            i = e ? Ea(e) : null,
            o = Ha(t),
            u = !1,
            c = !1;
        if (r in ua) {
            var s = ua[r];
            if (s.metadata.active = !0, s.previous !== o && (u = !0, s.previous = o), s.parent !== i) {
                u = !0;
                var l = s.parent;
                if (s.parent = i, null !== i && i >= 0) {
                    var d = null === o ? 0 : ua[i].children.indexOf(o) + 1;
                    ua[i].children.splice(d, 0, r), s.region = Za(t) ? r : ua[i].region
                } else ! function(t, e) {
                    if (t in ua) {
                        var n = ua[t];
                        n.metadata.active = !1, n.parent = null, qa(t, e), za(t)
                    }
                }(r, a);
                if (null !== l && l >= 0) {
                    var f = ua[l].children.indexOf(r);
                    f >= 0 && ua[l].children.splice(f, 1)
                }
                c = !0
            }
            for (var p in n) Da(s.data, n, p) && (u = !0, s.data[p] = n[p]);
            Pa(s), qa(r, a, u, c)
        }
    }

    function xa(t) {
        var e = !1;
        if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
            var n = t;
            try {
                n.contentDocument && (ma.set(n.contentDocument, n), ya.set(n, {
                    doc: n.contentDocument,
                    win: n.contentWindow
                }), e = !0)
            } catch (t) {}
        }
        return e
    }

    function _a(t) {
        var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
        return e && ma.has(e) ? ma.get(e) : null
    }

    function Ia(t) {
        return ya.has(t) ? ya.get(t) : null
    }

    function Ca(t, e) {
        ya.delete(t), ma.delete(e)
    }

    function Da(t, e, n) {
        if ("object" == typeof t[n] && "object" == typeof e[n]) {
            for (var a in t[n])
                if (t[n][a] !== e[n][a]) return !0;
            for (var a in e[n])
                if (e[n][a] !== t[n][a]) return !0;
            return !1
        }
        return t[n] !== e[n]
    }

    function Pa(t) {
        var e = t.parent && t.parent in ua ? ua[t.parent] : null,
            n = e ? e.selector : null,
            a = t.data,
            r = function(t, e) {
                e.metadata.position = 1;
                for (var n = t ? t.children.indexOf(e.id) : -1; n-- > 0;) {
                    var a = ua[t.children[n]];
                    if (e.data.tag === a.data.tag) {
                        e.metadata.position = a.metadata.position + 1;
                        break
                    }
                }
                return e.metadata.position
            }(e, t),
            i = {
                id: t.id,
                tag: a.tag,
                prefix: n,
                position: r,
                attributes: a.attributes
            };
        t.selector = [aa(i, 0), aa(i, 1)], t.hash = t.selector.map((function(t) {
            return t ? f(t) : null
        })), t.hash.forEach((function(e) {
            return sa[e] = t.id
        }))
    }

    function Ra(t) {
        var e = Aa(ja(t));
        return null !== e && null !== e.textContent ? e.textContent.substr(0, 25) : ""
    }

    function Aa(t) {
        return oa.has(t) ? oa.get(t) : null
    }

    function Xa(t) {
        return t in ua ? ua[t] : null
    }

    function Ya(t) {
        var e = Ea(t);
        return e in ua ? ua[e] : null
    }

    function ja(t) {
        return t in sa ? sa[t] : null
    }

    function La(t) {
        return oa.has(Ea(t))
    }

    function Wa() {
        for (var t = [], e = 0, n = ca; e < n.length; e++) {
            var a = n[e];
            a in ua && t.push(ua[a])
        }
        return ca = [], t
    }

    function za(t) {
        var e = oa.get(t);
        if ((null == e ? void 0 : e.nodeType) !== Node.DOCUMENT_FRAGMENT_NODE) {
            if (e && (null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE && "IFRAME" === e.tagName) Qn(e);
            oa.delete(t);
            var n = t in ua ? ua[t] : null;
            if (n && n.children)
                for (var a = 0, r = n.children; a < r.length; a++) {
                    za(r[a])
                }
        }
    }

    function Ha(t) {
        for (var e = null; null === e && t.previousSibling;) e = Ea(t.previousSibling), t = t.previousSibling;
        return e
    }

    function qa(t, e, n, a) {
        if (void 0 === n && (n = !0), void 0 === a && (a = !1), !u.lean || !u.lite) {
            var r = ca.indexOf(t);
            r >= 0 && 1 === e && a ? (ca.splice(r, 1), ca.push(t)) : -1 === r && n && ca.push(t)
        }
    }
    var Ua = [],
        Fa = null,
        Va = {},
        Ba = [],
        Ja = !1,
        Ga = null;

    function Ka(t, e) {
        !1 === Fa.has(t) && (Fa.set(t, e), (Ga = null === Ga && Ja ? new IntersectionObserver($a, {
            threshold: [0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        }) : Ga) && t && t.nodeType === Node.ELEMENT_NODE && Ga.observe(t))
    }

    function Za(t) {
        return Fa && Fa.has(t)
    }

    function Qa() {
        Qa.dn = 24;
        for (var t = [], e = 0, n = Ba; e < n.length; e++) {
            var a = n[e],
                r = Ea(a.node);
            r ? (a.state.data.id = r, Va[r] = a.state.data, Ua.push(a.state)) : t.push(a)
        }
        Ba = t, Ua.length > 0 && bn(7)
    }

    function $a(t) {
        for (var e = 0, n = t; e < n.length; e++) {
            var a = n[e],
                r = a.target,
                i = a.boundingClientRect,
                o = a.intersectionRect,
                u = a.rootBounds;
            if (Fa.has(r) && i.width + i.height > 0 && u.width > 0 && u.height > 0) {
                var c = r ? Ea(r) : null,
                    s = c in Va ? Va[c] : {
                        id: c,
                        name: Fa.get(r),
                        interaction: 16,
                        visibility: 0
                    },
                    l = (o ? o.width * o.height * 1 / (u.width * u.height) : 0) > .05 || a.intersectionRatio > .8,
                    d = (l || 10 == s.visibility) && Math.abs(i.top) + u.height > i.height;
                tr(r, s, s.interaction, d ? 13 : l ? 10 : 0), s.visibility >= 13 && Ga && Ga.unobserve(r)
            }
        }
        Ua.length > 0 && bn(7)
    }

    function tr(t, e, n, a) {
        var r = n > e.interaction || a > e.visibility;
        e.interaction = n > e.interaction ? n : e.interaction, e.visibility = a > e.visibility ? a : e.visibility, e.id ? (e.id in Va && r || !(e.id in Va)) && (Va[e.id] = e, Ua.push(er(e))) : Ba.push({
            node: t,
            state: er(e)
        })
    }

    function er(t) {
        return {
            time: l(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function nr() {
        Ua = []
    }

    function ar(t) {
        var e = t.composed && t.composedPath ? t.composedPath() : null,
            n = e && e.length > 0 ? e[0] : t.target;
        return Dn = l() + 3e3, n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    }

    function rr(t, e, n) {
        void 0 === n && (n = null);
        var a = {
            id: 0,
            hash: null,
            privacy: 2
        };
        if (t) {
            var r = Ya(t);
            if (null !== r) {
                var i = r.metadata;
                a.id = r.id, a.hash = r.hash, a.privacy = i.privacy, r.region && function(t, e) {
                    var n = Aa(t),
                        a = t in Va ? Va[t] : {
                            id: t,
                            visibility: 0,
                            interaction: 16,
                            name: Fa.get(n)
                        },
                        r = 16;
                    switch (e) {
                        case 9:
                            r = 20;
                            break;
                        case 27:
                            r = 30
                    }
                    tr(n, a, r, a.visibility)
                }(r.region, e), i.fraud && jt(i.fraud, r.id, n || r.data.value)
            }
        }
        return a
    }

    function ir(t, e) {
        return void 0 === e && (e = null), nt(this, void 0, void 0, (function() {
            var n, a, r, i, o, u, c, s, d, f, p, h, v, g, m, y, k, S, O, T, E, M, N, x, _, C, P, R, A, X, Y, j, L, W, z;
            return at(this, (function(H) {
                switch (n = e || l(), a = [n, t], t) {
                    case 13:
                    case 14:
                    case 12:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        for (r = 0, i = ie; r < i.length; r++) W = i[r], (o = rr(W.data.target, W.event)).id > 0 && ((a = [W.time, W.event]).push(o.id), a.push(W.data.x), a.push(W.data.y), void 0 !== W.data.id && (a.push(W.data.id), void 0 !== W.data.isPrimary && a.push(W.data.isPrimary.toString())), kr(a), (void 0 === W.data.isPrimary || W.data.isPrimary) && I(W.event, W.data.x, W.data.y, W.time));
                        he();
                        break;
                    case 9:
                        for (u = 0, c = Ut; u < c.length; u++) W = c[u], s = rr(W.data.target, W.event, W.data.text), a = [W.time, W.event], d = s.hash ? s.hash.join(".") : "", a.push(s.id), a.push(W.data.x), a.push(W.data.y), a.push(W.data.eX), a.push(W.data.eY), a.push(W.data.button), a.push(W.data.reaction), a.push(W.data.context), a.push(b(W.data.text, "click", s.privacy)), a.push(w(W.data.link)), a.push(d), a.push(W.data.trust), a.push(W.data.isFullText), kr(a), sr(W.time, W.event, d, W.data.x, W.data.y, W.data.reaction, W.data.context);
                        Gt();
                        break;
                    case 38:
                        for (f = 0, p = Kt; f < p.length; f++) W = p[f], a = [W.time, W.event], (Y = rr(W.data.target, W.event)).id > 0 && (a.push(Y.id), a.push(W.data.action), kr(a));
                        Qt();
                        break;
                    case 11:
                        h = re, a.push(h.width), a.push(h.height), I(t, h.width, h.height), be(), kr(a);
                        break;
                    case 26:
                        v = Re, a.push(v.name), a.push(v.persisted), We(), kr(a);
                        break;
                    case 27:
                        for (g = 0, m = te; g < m.length; g++) W = m[g], y = rr(W.data.target, W.event, W.data.value), (a = [W.time, W.event]).push(y.id), a.push(b(W.data.value, "input", y.privacy, !1, W.data.type)), kr(a);
                        ae();
                        break;
                    case 21:
                        (k = xe) && (S = rr(k.start, t), O = rr(k.end, t), a.push(S.id), a.push(k.startOffset), a.push(O.id), a.push(k.endOffset), Pe(), kr(a));
                        break;
                    case 10:
                        for (T = 0, E = we; T < E.length; T++) W = E[T], M = rr(W.data.target, W.event), N = rr(W.data.top, W.event), x = rr(W.data.bottom, W.event), _ = (null == N ? void 0 : N.hash) ? N.hash.join(".") : "", C = (null == x ? void 0 : x.hash) ? x.hash.join(".") : "", M.id > 0 && ((a = [W.time, W.event]).push(M.id), a.push(W.data.x), a.push(W.data.y), a.push(_), a.push(C), kr(a), I(W.event, W.data.x, W.data.y, W.time));
                        we = [], ke = null, Se = null;
                        break;
                    case 42:
                        for (P = 0, R = Lt; P < R.length; P++) W = R[P], a = [W.time, W.event], (Y = rr(W.data.target, W.event)).id > 0 && ((a = [W.time, W.event]).push(Y.id), a.push(W.data.type), a.push(b(W.data.value, "change", Y.privacy)), a.push(b(W.data.checksum, "checksum", Y.privacy)), kr(a));
                        zt();
                        break;
                    case 39:
                        for (A = 0, X = Xe; A < X.length; A++) W = X[A], a = [W.time, W.event], (Y = rr(W.data.target, W.event)).id > 0 && (a.push(Y.id), kr(a));
                        je();
                        break;
                    case 22:
                        for (j = 0, L = ur; j < L.length; j++) W = L[j], (a = [W.time, W.event]).push(W.data.type), a.push(W.data.hash), a.push(W.data.x), a.push(W.data.y), a.push(W.data.reaction), a.push(W.data.context), kr(a, !1);
                        cr();
                        break;
                    case 28:
                        z = Ae, a.push(z.visible), kr(a), D(n, z.visible), He()
                }
                return [2]
            }))
        }))
    }
    var or = [],
        ur = [];

    function cr() {
        ur = []
    }

    function sr(t, e, n, a, r, i, o) {
        void 0 === i && (i = 1), void 0 === o && (o = 0), or.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: n,
                x: a,
                y: r,
                reaction: i,
                context: o
            }
        }), I(e, a, r, t)
    }
    var lr, dr, fr, pr, hr, vr = 0,
        gr = 0,
        mr = null,
        yr = 0,
        br = !1;

    function wr() {
        pr = !0, vr = 0, gr = 0, br = !1, yr = 0, lr = [], dr = [], fr = {}, hr = null
    }

    function kr(t, e) {
        if (void 0 === e && (e = !0), pr) {
            var n = l(),
                a = t.length > 1 ? t[1] : null,
                r = JSON.stringify(t);
            switch (u.lean ? !br && gr + r.length > 10485760 && (Pr(10, 0), br = !0) : br = !1, a) {
                case 5:
                    if (br) break;
                    vr += r.length;
                case 37:
                case 6:
                case 43:
                case 45:
                case 46:
                    if (br) break;
                    gr += r.length, lr.push(r);
                    break;
                default:
                    dr.push(r)
            }
            W(25);
            var i = function() {
                var t = !1 === u.lean && vr > 0 ? 100 : Li.sequence * u.delay;
                return "string" == typeof u.upload ? Math.max(Math.min(t, 3e4), 100) : u.delay
            }();
            n - yr > 2 * i && (U(mr), mr = null), e && null === mr && (25 !== a && J(), mr = q(Or, i), yr = n, ii(gr))
        }
    }

    function Sr() {
        U(mr), Or(!0), vr = 0, gr = 0, br = !1, yr = 0, lr = [], dr = [], fr = {}, hr = null, pr = !1
    }

    function Or(t) {
        return void 0 === t && (t = !1), nt(this, void 0, void 0, (function() {
            var e, n, a, r, i, o, c, s;
            return at(this, (function(l) {
                switch (l.label) {
                    case 0:
                        return mr = null, (e = !1 === u.lean && gr > 0 && (gr < 1048576 || Li.sequence > 0)) && H(1, 1), Qa(),
                            function() {
                                var t = [];
                                ur = [];
                                for (var e = Li.start + Li.duration, n = Math.max(e - 2e3, 0), a = 0, r = or; a < r.length; a++) {
                                    var i = r[a];
                                    i.time >= n && (i.time <= e && ur.push(i), t.push(i))
                                }
                                or = t, ir(22)
                            }(), At(),
                            function() {
                                for (var t = 0, e = Ke; t < e.length; t++) {
                                    var n = e[t],
                                        a = n == document ? -1 : Ea(n);
                                    tn(n, a in Ge ? Ge[a] : null)
                                }
                            }(), n = !0 === t, a = JSON.stringify(Hi(n)), r = "[".concat(dr.join(), "]"), i = e ? "[".concat(lr.join(), "]") : "", o = function(t) {
                                return t.p.length > 0 ? '{"e":'.concat(t.e, ',"a":').concat(t.a, ',"p":').concat(t.p, "}") : '{"e":'.concat(t.e, ',"a":').concat(t.a, "}")
                            }({
                                e: a,
                                a: r,
                                p: i
                            }), n ? (s = null, [3, 3]) : [3, 1];
                    case 1:
                        return [4, it(o)];
                    case 2:
                        s = l.sent(), l.label = 3;
                    case 3:
                        return z(2, (c = s) ? c.length : o.length), Tr(o, c, Li.sequence, n), dr = [], e && (lr = [], gr = 0, vr = 0, br = !1), [2]
                }
            }))
        }))
    }

    function Tr(t, e, n, a) {
        if (void 0 === a && (a = !1), "string" == typeof u.upload) {
            var r = u.upload,
                i = !1;
            if (a && "sendBeacon" in navigator) try {
                (i = navigator.sendBeacon.bind(navigator)(r, t)) && Mr(n)
            } catch (t) {}
            if (!1 === i) {
                n in fr ? fr[n].attempts++ : fr[n] = {
                    data: t,
                    attempts: 1
                };
                var o = new XMLHttpRequest;
                o.open("POST", r, !0), o.timeout = 15e3, o.ontimeout = function() {
                    Ui(new Error("".concat("Timeout", " : ").concat(r)))
                }, null !== n && (o.onreadystatechange = function() {
                    Fi(Er)(o, n)
                }), o.withCredentials = !0, e ? (o.setRequestHeader("Accept", "application/x-clarity-gzip"), o.send(e)) : o.send(t)
            }
        } else if (u.upload) {
            (0, u.upload)(t), Mr(n)
        }
    }

    function Er(t, e) {
        var n = fr[e];
        t && 4 === t.readyState && n && ((t.status < 200 || t.status > 208) && n.attempts <= 1 ? t.status >= 400 && t.status < 500 ? oi(6) : (0 === t.status && (u.upload = u.fallback ? u.fallback : u.upload), Tr(n.data, null, e)) : (hr = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, n.attempts > 1 && ai(2), 200 === t.status && t.responseText && function(t) {
            for (var e = t && t.length > 0 ? t.split("\n") : [], n = 0, a = e; n < a.length; n++) {
                var r = a[n],
                    i = r && r.length > 0 ? r.split(/ (.*)/) : [""];
                switch (i[0]) {
                    case "END":
                        oi(6);
                        break;
                    case "UPGRADE":
                        ei("Auto");
                        break;
                    case "ACTION":
                        u.action && i.length > 1 && u.action(i[1]);
                        break;
                    case "EXTRACT":
                        i.length > 1 && St(i[1]);
                        break;
                    case "SIGNAL":
                        i.length > 1 && Ct(i[1])
                }
            }
        }(t.responseText), 0 === t.status && (Tr(n.data, null, e, !0), oi(3)), t.status >= 200 && t.status <= 208 && Mr(e), delete fr[e]))
    }

    function Mr(t) {
        1 === t && (_i(), xi())
    }
    var Nr, xr = {};

    function _r(t) {
        _r.dn = 4;
        var e = t.error || t;
        return e.message in xr || (xr[e.message] = 0), xr[e.message]++ >= 5 || e && e.message && (Nr = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename
        }, Ir(31)), !0
    }

    function Ir(t) {
        return nt(this, void 0, void 0, (function() {
            var e;
            return at(this, (function(n) {
                switch (e = [l(), t], t) {
                    case 31:
                        e.push(Nr.message), e.push(Nr.line), e.push(Nr.column), e.push(Nr.stack), e.push(w(Nr.source)), kr(e);
                        break;
                    case 33:
                        Cr && (e.push(Cr.code), e.push(Cr.name), e.push(Cr.message), e.push(Cr.stack), e.push(Cr.severity), kr(e, !1));
                        break;
                    case 41:
                        Xt && (e.push(Xt.id), e.push(Xt.target), e.push(Xt.checksum), kr(e, !1))
                }
                return [2]
            }))
        }))
    }
    var Cr, Dr = {};

    function Pr(t, e, n, a, r) {
        void 0 === n && (n = null), void 0 === a && (a = null), void 0 === r && (r = null);
        var i = n ? "".concat(n, "|").concat(a) : "";
        t in Dr && Dr[t].indexOf(i) >= 0 || (Cr = {
            code: t,
            name: n,
            message: a,
            stack: r,
            severity: e
        }, t in Dr ? Dr[t].push(i) : Dr[t] = [i], Ir(33))
    }
    var Rr = 5e3,
        Ar = {},
        Xr = [],
        Yr = null,
        jr = null,
        Lr = null;

    function Wr() {
        Ar = {}, Xr = [], Yr = null, jr = null
    }

    function zr(t, e) {
        return void 0 === e && (e = 0), nt(this, void 0, void 0, (function() {
            var n, a, r;
            return at(this, (function(i) {
                for (n = 0, a = Xr; n < a.length; n++)
                    if (a[n].task === t) return [2];
                return r = new Promise((function(n) {
                    Xr[1 === e ? "unshift" : "push"]({
                        task: t,
                        resolve: n,
                        id: Ei()
                    })
                })), null === Yr && null === jr && Hr(), [2, r]
            }))
        }))
    }

    function Hr() {
        var t = Xr.shift();
        t && (Yr = t, t.task().then((function() {
            t.id === Ei() && (t.resolve(), Yr = null, Hr())
        })).catch((function(e) {
            t.id === Ei() && (e && Pr(0, 1, e.name, e.message, e.stack), Yr = null, Hr())
        })))
    }

    function qr(t) {
        var e = Br(t);
        return e in Ar ? performance.now() - Ar[e].start > Ar[e].yield ? 0 : 1 : 2
    }

    function Ur(t) {
        Ar[Br(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function Fr(t) {
        var e = performance.now(),
            n = Br(t),
            a = e - Ar[n].start;
        z(t.cost, a), W(5), Ar[n].calls > 0 && z(4, a)
    }

    function Vr(t) {
        var e;
        return nt(this, void 0, void 0, (function() {
            var n, a;
            return at(this, (function(r) {
                switch (r.label) {
                    case 0:
                        return (n = Br(t)) in Ar ? (Fr(t), a = Ar[n], [4, Jr()]) : [3, 2];
                    case 1:
                        a.yield = (null === (e = r.sent()) || void 0 === e ? void 0 : e.timeRemaining()) || 30,
                            function(t) {
                                var e = Br(t);
                                if (Ar && Ar[e]) {
                                    var n = Ar[e].calls,
                                        a = Ar[e].yield;
                                    Ur(t), Ar[e].calls = n + 1, Ar[e].yield = a
                                }
                            }(t), r.label = 2;
                    case 2:
                        return [2, n in Ar ? 1 : 2]
                }
            }))
        }))
    }

    function Br(t) {
        return "".concat(t.id, ".").concat(t.cost)
    }

    function Jr() {
        return nt(this, void 0, void 0, (function() {
            return at(this, (function(t) {
                switch (t.label) {
                    case 0:
                        return jr ? [4, jr] : [3, 2];
                    case 1:
                        t.sent(), t.label = 2;
                    case 2:
                        return [2, new Promise((function(t) {
                            Gr(t, {
                                timeout: Rr
                            })
                        }))]
                }
            }))
        }))
    }
    var Gr = window.requestIdleCallback || function(t, e) {
        var n = performance.now(),
            a = new MessageChannel,
            r = a.port1,
            i = a.port2;
        r.onmessage = function(a) {
            var r = performance.now(),
                o = r - n,
                u = r - a.data;
            if (u > 30 && o < e.timeout) requestAnimationFrame((function() {
                i.postMessage(r)
            }));
            else {
                var c = o > e.timeout;
                t({
                    didTimeout: c,
                    timeRemaining: function() {
                        return c ? 30 : Math.max(0, 30 - u)
                    }
                })
            }
        }, requestAnimationFrame((function() {
            i.postMessage(performance.now())
        }))
    };

    function Kr() {
        zr(Zr, 1).then((function() {
            Fi(Tn)(), Fi(Qa)(), Fi(Ne)()
        }))
    }

    function Zr() {
        return nt(this, void 0, void 0, (function() {
            var t, e;
            return at(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return t = l(), Ur(e = {
                            id: Ei(),
                            cost: 3
                        }), [4, En(document, e, 0, t)];
                    case 1:
                        return n.sent(), tn(document, t), [4, bn(5, e, t)];
                    case 2:
                        return n.sent(), Fr(e), [2]
                }
            }))
        }))
    }
    var Qr, $r = null;

    function ti() {
        !u.lean && u.upgrade && u.upgrade("Config"), $r = null
    }

    function ei(t) {
        so() && u.lean && (u.lean = !1, $r = {
            key: t
        }, xi(), _i(), u.upgrade && u.upgrade(t), ai(3), u.lite && (Kr(), $e()))
    }

    function ni() {
        $r = null
    }

    function ai(t) {
        var e = [l(), t];
        switch (t) {
            case 4:
                var n = M;
                n && ((e = [n.time, n.event]).push(n.data.visible), e.push(n.data.docWidth), e.push(n.data.docHeight), e.push(n.data.screenWidth), e.push(n.data.screenHeight), e.push(n.data.scrollX), e.push(n.data.scrollY), e.push(n.data.pointerX), e.push(n.data.pointerY), e.push(n.data.activityTime), e.push(n.data.scrollTime), e.push(n.data.pointerTime), e.push(n.data.moveX), e.push(n.data.moveY), e.push(n.data.moveTime), e.push(n.data.downX), e.push(n.data.downY), e.push(n.data.downTime), e.push(n.data.upX), e.push(n.data.upY), e.push(n.data.upTime), e.push(n.data.pointerPrevX), e.push(n.data.pointerPrevY), e.push(n.data.pointerPrevTime), kr(e, !1)), _();
                break;
            case 25:
                e.push(Y.gap), kr(e);
                break;
            case 35:
                e.push(Qr.check), kr(e, !1);
                break;
            case 3:
                e.push($r.key), kr(e);
                break;
            case 2:
                e.push(hr.sequence), e.push(hr.attempts), e.push(hr.status), kr(e, !1);
                break;
            case 24:
                A.key && e.push(A.key), e.push(A.value), kr(e);
                break;
            case 34:
                var a = Object.keys(ut);
                if (a.length > 0) {
                    for (var r = 0, i = a; r < i.length; r++) {
                        var o = i[r];
                        e.push(o), e.push(ut[o])
                    }
                    ft(), kr(e, !1)
                }
                break;
            case 0:
                var u = Object.keys(L);
                if (u.length > 0) {
                    for (var c = 0, s = u; c < s.length; c++) {
                        var d = s[c],
                            f = parseInt(d, 10);
                        e.push(f), e.push(Math.round(L[d]))
                    }
                    L = {}, kr(e, !1)
                }
                break;
            case 1:
                var p = Object.keys(li);
                if (p.length > 0) {
                    for (var h = 0, v = p; h < v.length; h++) {
                        var g = v[h];
                        f = parseInt(g, 10);
                        e.push(f), e.push(li[g])
                    }
                    gi(), kr(e, !1)
                }
                break;
            case 36:
                var m = Object.keys(Z);
                if (m.length > 0) {
                    for (var y = 0, b = m; y < b.length; y++) {
                        var w = b[y];
                        f = parseInt(w, 10);
                        e.push(f), e.push([].concat.apply([], Z[w]))
                    }
                    tt(), kr(e, !1)
                }
                break;
            case 40:
                mt.forEach((function(t) {
                    e.push(t);
                    var n = [];
                    for (var a in gt[t]) {
                        var r = parseInt(a, 10);
                        n.push(r), n.push(gt[t][a])
                    }
                    e.push(n)
                })), Et(), kr(e, !1)
        }
    }

    function ri() {
        Qr = {
            check: 0
        }
    }

    function ii(t) {
        if (0 === Qr.check) {
            var e = Qr.check;
            e = Li.sequence >= 128 ? 1 : e, e = Li.pageNum >= 128 ? 7 : e, e = l() > 72e5 ? 2 : e, (e = t > 10485760 ? 2 : e) !== Qr.check && oi(e)
        }
    }

    function oi(t) {
        Qr.check = t, 5 !== t && (Ni(), Ao())
    }

    function ui() {
        0 !== Qr.check && ai(35)
    }

    function ci() {
        Qr = null
    }
    var si = null,
        li = null,
        di = !1;

    function fi() {
        si = {}, li = {}, di = !1
    }

    function pi() {
        si = {}, li = {}, di = !1
    }

    function hi(t, e) {
        if (e && (e = "".concat(e), t in si || (si[t] = []), si[t].indexOf(e) < 0)) {
            if (si[t].length > 128) return void(di || (di = !0, oi(5)));
            si[t].push(e), t in li || (li[t] = []), li[t].push(e)
        }
    }

    function vi() {
        ai(1)
    }

    function gi() {
        li = {}, di = !1
    }

    function mi(t) {
        hi(36, t.toString())
    }
    var yi = null,
        bi = [],
        wi = 0,
        ki = null;

    function Si() {
        var t, e, n;
        ki = null;
        var a = navigator && "userAgent" in navigator ? navigator.userAgent : "",
            r = null !== (n = null === (e = null === (t = null === Intl || void 0 === Intl ? void 0 : Intl.DateTimeFormat()) || void 0 === t ? void 0 : t.resolvedOptions()) || void 0 === e ? void 0 : e.timeZone) && void 0 !== n ? n : "",
            i = (new Date).getTimezoneOffset().toString(),
            o = window.location.ancestorOrigins ? Array.from(window.location.ancestorOrigins).toString() : "",
            c = document && document.title ? document.title : "";
        wi = a.indexOf("Electron") > 0 ? 1 : 0;
        var s, l = function() {
                var t = {
                        session: Di(),
                        ts: Math.round(Date.now()),
                        count: 1,
                        upgrade: null,
                        upload: ""
                    },
                    e = Ai("_clsk", !u.includeSubdomains);
                if (e) {
                    var n = e.includes("^") ? e.split("^") : e.split("|");
                    n.length >= 5 && t.ts - Pi(n[1]) < 18e5 && (t.session = n[0], t.count = Pi(n[2]) + 1, t.upgrade = Pi(n[3]), t.upload = n.length >= 6 ? "".concat("https://").concat(n[5], "/").concat(n[4]) : "".concat("https://").concat(n[4]))
                }
                return t
            }(),
            d = Ri(),
            p = u.projectId || f(location.host);
        yi = {
            projectId: p,
            userId: d.id,
            sessionId: l.session,
            pageNum: l.count
        }, u.lean = u.track && null !== l.upgrade ? 0 === l.upgrade : u.lean, u.upload = u.track && "string" == typeof u.upload && l.upload && l.upload.length > "https://".length ? l.upload : u.upload, hi(0, a), hi(3, c), hi(1, w(location.href, !!wi)), hi(2, document.referrer), hi(15, function() {
            var t = Di();
            if (u.track && Ii(window, "sessionStorage")) {
                var e = sessionStorage.getItem("_cltk");
                t = e || t, sessionStorage.setItem("_cltk", t)
            }
            return t
        }()), hi(16, document.documentElement.lang), hi(17, document.dir), hi(26, "".concat(window.devicePixelRatio)), hi(28, d.dob.toString()), hi(29, d.version.toString()), hi(33, o), hi(34, r), hi(35, i), H(0, l.ts), H(1, 0), H(35, wi), navigator && (hi(9, navigator.language), H(33, navigator.hardwareConcurrency), H(32, navigator.maxTouchPoints), H(34, Math.round(navigator.deviceMemory)), (s = navigator.userAgentData) && s.getHighEntropyValues ? s.getHighEntropyValues(["model", "platform", "platformVersion", "uaFullVersion"]).then((function(t) {
            var e;
            hi(22, t.platform), hi(23, t.platformVersion), null === (e = t.brands) || void 0 === e || e.forEach((function(t) {
                hi(24, t.name + "~" + t.version)
            })), hi(25, t.model), H(27, t.mobile ? 1 : 0)
        })) : hi(22, navigator.platform)), screen && (H(14, Math.round(screen.width)), H(15, Math.round(screen.height)), H(16, Math.round(screen.colorDepth)));
        for (var h = 0, v = u.cookies; h < v.length; h++) {
            var g = v[h],
                m = Ai(g);
            m && ct(g, m)
        }! function(t) {
            mi(t ? 1 : 0)
        }(u.track), Ci(d)
    }

    function Oi() {
        ki = null, yi = null, bi.forEach((function(t) {
            t.called = !1
        }))
    }

    function Ti(t, e, n) {
        void 0 === e && (e = !0), void 0 === n && (n = !1);
        var a = u.lean ? 0 : 1,
            r = !1;
        yi && (a || !1 === e) && (t(yi, !u.lean), r = !0), !n && r || bi.push({
            callback: t,
            wait: e,
            recall: n,
            called: r
        })
    }

    function Ei() {
        return yi ? [yi.userId, yi.sessionId, yi.pageNum].join(".") : ""
    }

    function Mi(t) {
        if (void 0 === t && (t = !0), !t) return u.track = !1, Yi("_clsk", "", -Number.MAX_VALUE), Yi("_clck", "", -Number.MAX_VALUE), Ao(), void window.setTimeout(Ro, 250);
        so() && (u.track = !0, Ci(Ri(), 1), _i(), mi(2))
    }

    function Ni() {
        Yi("_clsk", "", 0)
    }

    function xi() {
        ! function(t) {
            if (bi.length > 0)
                for (var e = 0; e < bi.length; e++) {
                    var n = bi[e];
                    !n.callback || n.called || n.wait && !t || (n.callback(yi, !u.lean), n.called = !0, n.recall || (bi.splice(e, 1), e--))
                }
        }(u.lean ? 0 : 1)
    }

    function _i() {
        if (yi && u.track) {
            var t = Math.round(Date.now()),
                e = u.upload && "string" == typeof u.upload ? u.upload.replace("https://", "") : "",
                n = u.lean ? 0 : 1;
            Yi("_clsk", [yi.sessionId, t, yi.pageNum, n, e].join("|"), 1)
        }
    }

    function Ii(t, e) {
        try {
            return !!t[e]
        } catch (t) {
            return !1
        }
    }

    function Ci(t, e) {
        void 0 === e && (e = null), e = null === e ? t.consent : e;
        var n = Math.ceil((Date.now() + 31536e6) / 864e5),
            a = 0 === t.dob ? null === u.dob ? 0 : u.dob : t.dob;
        (null === t.expiry || Math.abs(n - t.expiry) >= 1 || t.consent !== e || t.dob !== a) && Yi("_clck", [yi.userId, 2, n.toString(36), e, a].join("|"), 365)
    }

    function Di() {
        var t = Math.floor(Math.random() * Math.pow(2, 32));
        return window && window.crypto && window.crypto.getRandomValues && Uint32Array && (t = window.crypto.getRandomValues(new Uint32Array(1))[0]), t.toString(36)
    }

    function Pi(t, e) {
        return void 0 === e && (e = 10), parseInt(t, e)
    }

    function Ri() {
        var t = {
                id: Di(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            e = Ai("_clck", !u.includeSubdomains);
        if (e && e.length > 0) {
            var n = e.includes("^") ? e.split("^") : e.split("|");
            n.length > 1 && (t.version = Pi(n[1])), n.length > 2 && (t.expiry = Pi(n[2], 36)), n.length > 3 && 1 === Pi(n[3]) && (t.consent = 1), n.length > 4 && Pi(n[1]) > 1 && (t.dob = Pi(n[4])), u.track = u.track || 1 === t.consent, t.id = u.track ? n[0] : t.id
        }
        return t
    }

    function Ai(t, e) {
        var n;
        if (void 0 === e && (e = !1), Ii(document, "cookie")) {
            var a = document.cookie.split(";");
            if (a)
                for (var r = 0; r < a.length; r++) {
                    var i = a[r].split("=");
                    if (i.length > 1 && i[0] && i[0].trim() === t) {
                        for (var o = Xi(i[1]), u = o[0], c = o[1]; u;) u = (n = Xi(c))[0], c = n[1];
                        return e ? c.endsWith("".concat("~", "1")) ? c.substring(0, c.length - 2) : null : c
                    }
                }
        }
        return null
    }

    function Xi(t) {
        try {
            var e = decodeURIComponent(t);
            return [e != t, e]
        } catch (t) {}
        return [!1, t]
    }

    function Yi(t, e, n) {
        if ((u.track || "" == e) && (navigator && navigator.cookieEnabled || Ii(document, "cookie"))) {
            var a = function(t) {
                    return encodeURIComponent(t)
                }(e),
                r = new Date;
            r.setDate(r.getDate() + n);
            var i = r ? "expires=" + r.toUTCString() : "",
                o = "".concat(t, "=").concat(a).concat(";").concat(i).concat(";path=/");
            try {
                if (null === ki) {
                    for (var c = location.hostname ? location.hostname.split(".") : [], s = c.length - 1; s >= 0; s--)
                        if (ki = ".".concat(c[s]).concat(ki || ""), s < c.length - 1 && (document.cookie = "".concat(o).concat(";").concat("domain=").concat(ki), Ai(t) === e)) return;
                    ki = ""
                }
            } catch (t) {
                ki = ""
            }
            document.cookie = ki ? "".concat(o).concat(";").concat("domain=").concat(ki) : o
        }
    }
    var ji, Li = null;

    function Wi() {
        var t = yi;
        Li = {
            version: d,
            sequence: 0,
            start: 0,
            duration: 0,
            projectId: t.projectId,
            userId: t.userId,
            sessionId: t.sessionId,
            pageNum: t.pageNum,
            upload: 0,
            end: 0,
            applicationPlatform: 0,
            url: ""
        }
    }

    function zi() {
        Li = null
    }

    function Hi(t) {
        return Li.start = Li.start + Li.duration, Li.duration = l() - Li.start, Li.sequence++, Li.upload = t && "sendBeacon" in navigator ? 1 : 0, Li.end = t ? 1 : 0, Li.applicationPlatform = 0, Li.url = w(location.href, !1, !0), [Li.version, Li.sequence, Li.start, Li.duration, Li.projectId, Li.userId, Li.sessionId, Li.pageNum, Li.upload, Li.end, Li.applicationPlatform, Li.url]
    }

    function qi() {
        ji = []
    }

    function Ui(t) {
        if (ji && -1 === ji.indexOf(t.message)) {
            var e = u.report;
            if (e && e.length > 0) {
                var n = {
                    v: Li.version,
                    p: Li.projectId,
                    u: Li.userId,
                    s: Li.sessionId,
                    n: Li.pageNum
                };
                t.message && (n.m = t.message), t.stack && (n.e = t.stack);
                var a = new XMLHttpRequest;
                a.open("POST", e, !0), a.send(JSON.stringify(n)), ji.push(t.message)
            }
        }
        return t
    }

    function Fi(t) {
        return function() {
            var e = performance.now();
            try {
                t.apply(this, arguments)
            } catch (t) {
                throw Ui(t)
            }
            var n = performance.now() - e;
            z(4, n), n > 30 && (W(7), H(6, n), Pr(9, 0, "".concat(t.dn || t.name, "-").concat(n)))
        }
    }
    var Vi = new Map;

    function Bi(t, e, n, a, r) {
        void 0 === a && (a = !1), void 0 === r && (r = !0), n = Fi(n);
        try {
            t[c("addEventListener")](e, n, {
                capture: a,
                passive: r
            }), Ki(t) || Vi.set(t, []), Vi.get(t).push({
                event: e,
                listener: n,
                options: {
                    capture: a,
                    passive: r
                }
            })
        } catch (t) {}
    }

    function Ji() {
        Vi.forEach((function(t, e) {
            Zi(t, e)
        })), Vi = new Map
    }

    function Gi(t) {
        Ki(t) && Zi(Vi.get(t), t)
    }

    function Ki(t) {
        return Vi.has(t)
    }

    function Zi(t, e) {
        t.forEach((function(t) {
            try {
                e[c("removeEventListener")](t.event, t.listener, {
                    capture: t.options.capture,
                    passive: t.options.passive
                })
            } catch (t) {}
        })), Vi.delete(e)
    }
    var Qi = null,
        $i = null,
        to = null,
        eo = 0;

    function no() {
        return !(eo++ > 20) || (Pr(4, 0), !1)
    }

    function ao() {
        ao.dn = 1, eo = 0, to !== io() && (Ao(), window.setTimeout(ro, 250))
    }

    function ro() {
        Ro(), H(29, 1)
    }

    function io() {
        return location.href ? location.href.replace(location.hash, "") : location.href
    }
    var oo = !1;

    function uo() {
        oo = !0, s = performance.now() + performance.timeOrigin, Wr(), Ji(), qi(), to = io(), eo = 0, Bi(window, "popstate", ao), null === Qi && (Qi = history.pushState, history.pushState = function() {
            Qi.apply(this, arguments), so() && no() && ao()
        }), null === $i && ($i = history.replaceState, history.replaceState = function() {
            $i.apply(this, arguments), so() && no() && ao()
        })
    }

    function co() {
        to = null, eo = 0, qi(), Ji(), Wr(), s = 0, oo = !1
    }

    function so() {
        return oo
    }

    function lo() {
        lo.dn = 2, Ro(), X("clarity", "restart")
    }
    var fo = Object.freeze({
        __proto__: null,
        start: function t() {
            t.dn = 3,
                function() {
                    Yt = [], H(26, navigator.webdriver ? 1 : 0);
                    try {
                        H(31, window.top == window.self || window.top == window ? 1 : 2)
                    } catch (t) {
                        H(31, 0)
                    }
                }(), Bi(window, "error", _r), xr = {}, Dr = {}
        },
        stop: function() {
            Dr = {}
        }
    });
    var po = Object.freeze({
        __proto__: null,
        hashText: Ra,
        start: function t() {
            t.dn = 20, On(), Tn(), nr(), Ga = null, Fa = new WeakMap, Va = {}, Ba = [], Ja = !!window.IntersectionObserver, ka(), u.delayDom ? Bi(window, "load", (function() {
                    Xn()
                })) : Xn(), Kr(), $e(),
                function() {
                    if (window.Animation && window.Animation.prototype && window.KeyframeEffect && window.KeyframeEffect.prototype && window.KeyframeEffect.prototype.getKeyframes && window.KeyframeEffect.prototype.getTiming && (vn(), mn(un, "play"), mn(cn, "pause"), mn(sn, "commitStyles"), mn(ln, "cancel"), mn(dn, "finish"), null === on && (on = Element.prototype.animate, Element.prototype.animate = function() {
                            var t = on.apply(this, arguments);
                            return yn(t, "play"), t
                        }), document.getAnimations))
                        for (var t = 0, e = document.getAnimations(); t < e.length; t++) {
                            var n = e[t];
                            "finished" === n.playState ? yn(n, "finish") : "paused" === n.playState || "idle" === n.playState ? yn(n, "pause") : "running" === n.playState && yn(n, "play")
                        }
                }()
        },
        stop: function() {
            nr(), Fa = null, Va = {}, Ba = [], Ga && (Ga.disconnect(), Ga = null), Ja = !1, Sa(),
                function() {
                    for (var t = 0, e = Array.from(Mn); t < e.length; t++) {
                        var n = e[t];
                        n && n.disconnect()
                    }
                    Mn = new Set, Pn = {}, Nn = [], xn = {}, _n = [], Dn = 0, In = null, Rn = new WeakMap
                }(), On(), Je = {}, Ge = {}, Ke = [], Ze = [], en(), vn()
        }
    });
    var ho = null;

    function vo() {
        ho = null
    }

    function go(t) {
        ho = {
                fetchStart: Math.round(t.fetchStart),
                connectStart: Math.round(t.connectStart),
                connectEnd: Math.round(t.connectEnd),
                requestStart: Math.round(t.requestStart),
                responseStart: Math.round(t.responseStart),
                responseEnd: Math.round(t.responseEnd),
                domInteractive: Math.round(t.domInteractive),
                domComplete: Math.round(t.domComplete),
                loadEventStart: Math.round(t.loadEventStart),
                loadEventEnd: Math.round(t.loadEventEnd),
                redirectCount: Math.round(t.redirectCount),
                size: t.transferSize ? t.transferSize : 0,
                type: t.type,
                protocol: t.nextHopProtocol,
                encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
                decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
            },
            function(t) {
                nt(this, void 0, void 0, (function() {
                    var e, n;
                    return at(this, (function(a) {
                        return e = l(), n = [e, t], 29 === t && (n.push(ho.fetchStart), n.push(ho.connectStart), n.push(ho.connectEnd), n.push(ho.requestStart), n.push(ho.responseStart), n.push(ho.responseEnd), n.push(ho.domInteractive), n.push(ho.domComplete), n.push(ho.loadEventStart), n.push(ho.loadEventEnd), n.push(ho.redirectCount), n.push(ho.size), n.push(ho.type), n.push(ho.protocol), n.push(ho.encodedSize), n.push(ho.decodedSize), vo(), kr(n)), [2]
                    }))
                }))
            }(29)
    }
    var mo, yo = 0,
        bo = 1 / 0,
        wo = 0,
        ko = 0,
        So = [],
        Oo = new Map,
        To = function() {
            return yo || 0
        },
        Eo = function() {
            if (!So.length) return -1;
            var t = Math.min(So.length - 1, Math.floor((To() - ko) / 50));
            return So[t].latency
        },
        Mo = function() {
            ko = To(), So.length = 0, Oo.clear()
        },
        No = function(t) {
            if (t.interactionId && !(t.duration < 40)) {
                ! function(t) {
                    "interactionCount" in performance ? yo = performance.interactionCount : t.interactionId && (bo = Math.min(bo, t.interactionId), wo = Math.max(wo, t.interactionId), yo = wo ? (wo - bo) / 7 + 1 : 0)
                }(t);
                var e = So[So.length - 1],
                    n = Oo.get(t.interactionId);
                if (n || So.length < 10 || t.duration > (null == e ? void 0 : e.latency)) {
                    if (n) t.duration > n.latency && (n.latency = t.duration);
                    else {
                        var a = {
                            id: t.interactionId,
                            latency: t.duration
                        };
                        Oo.set(a.id, a), So.push(a)
                    }
                    So.sort((function(t, e) {
                        return e.latency - t.latency
                    })), So.length > 10 && So.splice(10).forEach((function(t) {
                        return Oo.delete(t.id)
                    }))
                }
            }
        },
        xo = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"];

    function _o() {
        _o.dn = 26;
        try {
            mo && mo.disconnect(), mo = new PerformanceObserver(Fi(Io));
            for (var t = 0, e = xo; t < e.length; t++) {
                var n = e[t];
                PerformanceObserver.supportedEntryTypes.indexOf(n) >= 0 && ("layout-shift" === n && z(9, 0), mo.observe({
                    type: n,
                    buffered: !0
                }))
            }
        } catch (t) {
            Pr(3, 1)
        }
    }

    function Io(t) {
        Io.dn = 27,
            function(t) {
                for (var e = (!("visibilityState" in document) || "visible" === document.visibilityState), n = 0; n < t.length; n++) {
                    var a = t[n];
                    switch (a.entryType) {
                        case "navigation":
                            go(a);
                            break;
                        case "resource":
                            var r = a.name;
                            hi(4, Co(r)), r !== u.upload && r !== u.fallback || H(28, a.duration);
                            break;
                        case "longtask":
                            W(7);
                            break;
                        case "first-input":
                            e && H(10, a.processingStart - a.startTime);
                            break;
                        case "event":
                            e && "PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && (No(a), hi(37, Eo().toString()));
                            break;
                        case "layout-shift":
                            e && !a.hadRecentInput && z(9, 1e3 * a.value);
                            break;
                        case "largest-contentful-paint":
                            e && H(8, a.startTime)
                    }
                }
            }(t.getEntries())
    }

    function Co(t) {
        var e = document.createElement("a");
        return e.href = t, e.host
    }
    var Do = Object.freeze({
            __proto__: null,
            start: function t() {
                t.dn = 25, vo(),
                    function() {
                        navigator && "connection" in navigator && hi(27, navigator.connection.effectiveType), window.PerformanceObserver && PerformanceObserver.supportedEntryTypes ? "complete" !== document.readyState ? Bi(window, "load", q.bind(this, _o, 0)) : _o() : Pr(3, 0)
                    }()
            },
            stop: function() {
                mo && mo.disconnect(), mo = null, Mo(), vo()
            }
        }),
        Po = [fo, po, Ue, Do];

    function Ro(t) {
        void 0 === t && (t = null),
            function() {
                try {
                    var t = navigator && "globalPrivacyControl" in navigator && 1 == navigator.globalPrivacyControl;
                    return !1 === oo && "undefined" != typeof Promise && window.MutationObserver && document.createTreeWalker && "now" in Date && "now" in performance && "undefined" != typeof WeakMap && !t
                } catch (t) {
                    return !1
                }
            }() && (! function(t) {
                if (null === t || oo) return !1;
                for (var e in t) e in u && (u[e] = t[e])
            }(t), uo(), Pt(), Po.forEach((function(t) {
                return Fi(t.start)()
            })), null === t && Lo())
    }

    function Ao() {
        so() && (Po.slice().reverse().forEach((function(t) {
            return Fi(t.stop)()
        })), Rt(), co(), void 0 !== Yo && (Yo[jo] = function() {
            (Yo[jo].q = Yo[jo].q || []).push(arguments), "start" === arguments[0] && Yo[jo].q.unshift(Yo[jo].q.pop()) && Lo()
        }))
    }
    var Xo = Object.freeze({
            __proto__: null,
            consent: Mi,
            event: X,
            hashText: Ra,
            identify: st,
            metadata: Ti,
            pause: function() {
                so() && (X("clarity", "pause"), null === jr && (jr = new Promise((function(t) {
                    Lr = t
                }))))
            },
            resume: function() {
                so() && (jr && (Lr(), jr = null, null === Yr && Hr()), X("clarity", "resume"))
            },
            set: ct,
            signal: function(t) {
                It = t
            },
            start: Ro,
            stop: Ao,
            upgrade: ei,
            version: d
        }),
        Yo = window,
        jo = "clarity";

    function Lo() {
        if (void 0 !== Yo) {
            if (Yo[jo] && Yo[jo].v) return console.warn("Error CL001: Multiple Clarity tags detected.");
            var t = Yo[jo] && Yo[jo].q || [];
            for (Yo[jo] = function(t) {
                    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                    return Xo[t].apply(Xo, e)
                }, Yo[jo].v = d; t.length > 0;) Yo[jo].apply(Yo, t.shift())
        }
    }
    Lo()
}();